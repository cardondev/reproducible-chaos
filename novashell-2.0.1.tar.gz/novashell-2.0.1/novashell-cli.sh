#!/bin/bash
# NovaShell per-user CLI.
#
# Installed as /usr/bin/novashell by the RPM. Provides explicit, per-user opt-in
# so that a single system-wide install can coexist with users who do NOT want
# NovaShell as their shell config (shared-environment friendly).
#
# Subcommands:
#   enable    Copy bashrc/profile/vimrc/tmux.conf into $HOME; mark opted-in.
#   disable   Restore original files from backup; remove marker.
#   status    Show install / opt-in state for the current user.
#   update    Re-run enable to pick up package updates (preserves backup).
#   help      Print usage.
#
# Cleanup logic on (re)enable:
#   - Rotates old backups: keeps the 3 most recent ~/.novashell_backup_*.
#   - Removes orphaned prefix-mode files if switching to native.
#   - Never touches files that lack the NovaShell sentinel comment.

set -euo pipefail

NOVASHELL_DIR="${NOVASHELL_DIR:-/usr/share/novashell}"
KEEP_BACKUPS=3
SENTINEL='# BASHRC - NovaShell'

# Install mode: "native" (default) or "prefix". MARKER / BACKUP_BASE / FILE_MAP
# are derived after resolve_paths runs.
MODE="native"
PREFIX=""
MARKER=""
BACKUP_BASE=""
declare -A FILE_MAP=()

# ---- colors -------------------------------------------------------------------
G='\e[38;5;151m' ; Y='\e[38;5;223m' ; C='\e[38;5;116m' ; R='\e[38;5;203m' ; B='\e[38;5;111m' ; N='\e[0m'

die()  { echo -e "${R}error:${N} $*" >&2; exit 1; }
info() { echo -e "${C}=>${N} $*"; }
ok()   { echo -e "${G}✓${N} $*"; }
warn() { echo -e "${Y}!${N} $*"; }

[[ -d "$NOVASHELL_DIR/aliases.d" ]] || die "NovaShell source not found at $NOVASHELL_DIR (is the package installed?)"

valid_prefix() {
    [[ "$1" =~ ^\.?[A-Za-z][A-Za-z0-9_-]*$ ]]
}

resolve_paths() {
    if [[ "$MODE" == "prefix" ]]; then
        MARKER="$HOME/${PREFIX}_installed"
        BACKUP_BASE="$HOME/${PREFIX}_backup"
        FILE_MAP=(
            ["bashrc"]="${PREFIX}_bashrc"
            ["bash_profile"]="${PREFIX}_bash_profile"
            ["vimrc"]="${PREFIX}_vimrc"
            ["tmux.conf"]="${PREFIX}_tmux.conf"
        )
    else
        MARKER="$HOME/.novashell_installed"
        BACKUP_BASE="$HOME/.novashell_backup"
        FILE_MAP=(
            ["bashrc"]=".bashrc"
            ["bash_profile"]=".bash_profile"
            ["vimrc"]=".vimrc"
            ["tmux.conf"]=".tmux.conf"
        )
    fi
}

# ---- cleanup: rotate old backups ---------------------------------------------
rotate_backups() {
    [[ "$MODE" == "prefix" ]] && return 0
    local backups
    mapfile -t backups < <(ls -1dt "${BACKUP_BASE}"_* 2>/dev/null || true)
    local total=${#backups[@]}
    (( total <= KEEP_BACKUPS )) && return 0
    local i
    for (( i=KEEP_BACKUPS; i<total; i++ )); do
        rm -rf "${backups[i]}"
        info "rotated old backup: ${backups[i]}"
    done
}

# ---- cleanup: remove orphaned prefix-mode files (native installs only) -------
cleanup_orphans() {
    [[ "$MODE" == "prefix" ]] && return 0
    local prefix=".novashell"
    local f
    for f in _bashrc _bash_profile _aliases _functions _vimrc _tmux.conf; do
        local target="$HOME/${prefix}${f}"
        if [[ -f "$target" ]]; then
            rm -f "$target"
            info "removed orphaned prefix file: $target"
        fi
    done
    # Legacy v1.x monolithic sourced files
    for f in .bash_aliases .bash_functions; do
        if [[ -f "$HOME/$f" ]] && head -5 "$HOME/$f" 2>/dev/null | grep -q 'ALIASES - NovaShell\|FUNCTIONS - NovaShell'; then
            rm -f "$HOME/$f"
            info "removed legacy v1 file: $HOME/$f"
        fi
    done
}

# ---- backup --------------------------------------------------------------------
do_backup() {
    # Prefix mode never touches the user's real dotfiles — nothing to back up.
    [[ "$MODE" == "prefix" ]] && return 0

    local stamp backup_dir
    stamp=$(date +%Y%m%d_%H%M%S)
    backup_dir="${BACKUP_BASE}_${stamp}"

    local any=0
    for src in "${!FILE_MAP[@]}"; do
        local target="${FILE_MAP[$src]}"
        if [[ -f "$HOME/$target" ]]; then
            # Skip files we installed ourselves (check sentinel); but back up
            # first-time originals.
            if ! head -3 "$HOME/$target" 2>/dev/null | grep -q 'NovaShell'; then
                mkdir -p "$backup_dir"
                cp -a "$HOME/$target" "$backup_dir/$target"
                any=1
            fi
        fi
    done

    if [[ $any -eq 1 ]]; then
        cat > "$backup_dir/restore.sh" <<'RESTORE'
#!/bin/bash
# Restore originals captured by `novashell enable`.
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in "$SCRIPT_DIR"/.*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
    cp -a "$f" "$HOME/$fname"
    echo "restored: $fname"
done
RESTORE
        chmod +x "$backup_dir/restore.sh"
        ok "originals backed up → $backup_dir"
        echo "$backup_dir" > "$HOME/.novashell_last_backup"
    fi
}

# ---- install --------------------------------------------------------------------
do_install() {
    resolve_paths
    if [[ "$MODE" == "prefix" ]]; then
        info "installing NovaShell (prefix '$PREFIX') for $(whoami) from $NOVASHELL_DIR"
    else
        info "installing NovaShell for $(whoami) from $NOVASHELL_DIR"
    fi

    do_backup
    cleanup_orphans

    local bashrc_target="${FILE_MAP[bashrc]}"
    local profile_target="${FILE_MAP[bash_profile]}"

    if [[ "$MODE" == "prefix" ]]; then
        # Write an injected header that pins NOVASHELL_ROOT to the package tree
        # and sets MODE/PREFIX — so this prefixed bashrc is self-contained.
        {
            cat <<HEADER
# -----------------------------------------------------------------------------
# NovaShell prefix-mode header (injected by \`novashell enable --prefix\`)
export NOVASHELL_PREFIX="$PREFIX"
export NOVASHELL_MODE="prefix"
export NOVASHELL_ROOT="$NOVASHELL_DIR"
# -----------------------------------------------------------------------------

HEADER
            cat "$NOVASHELL_DIR/bashrc"
        } > "$HOME/$bashrc_target"
        chmod 644 "$HOME/$bashrc_target"
        ok "installed ~/$bashrc_target"

        cp "$NOVASHELL_DIR/bash_profile" "$HOME/$profile_target"
        chmod 644 "$HOME/$profile_target"
        # Rewrite so the prefixed profile sources the prefixed bashrc, not .bashrc.
        sed -i.bak "s|\$HOME/\.bashrc|\$HOME/${bashrc_target}|g" "$HOME/$profile_target"
        rm -f "$HOME/${profile_target}.bak"
        if ! grep -q "source.*${bashrc_target}" "$HOME/$profile_target" 2>/dev/null; then
            cat >> "$HOME/$profile_target" <<PROFILE

# Source ${bashrc_target} for login shells (prefix mode)
if [[ -f "\$HOME/${bashrc_target}" ]]; then
    source "\$HOME/${bashrc_target}"
fi
PROFILE
        fi
        ok "installed ~/$profile_target"

        for src in vimrc tmux.conf; do
            local target="${FILE_MAP[$src]}"
            [[ -f "$NOVASHELL_DIR/$src" ]] || continue
            cp "$NOVASHELL_DIR/$src" "$HOME/$target"
            chmod 644 "$HOME/$target"
            ok "installed ~/$target"
        done
    else
        # Native mode: straight copy from package tree.
        export NOVASHELL_ROOT="$NOVASHELL_DIR"
        export NOVASHELL_MODE="native"

        for src in "${!FILE_MAP[@]}"; do
            local target="${FILE_MAP[$src]}"
            local src_file="$NOVASHELL_DIR/$src"
            [[ -f "$src_file" ]] || continue
            cp "$src_file" "$HOME/$target"
            chmod 644 "$HOME/$target"
            ok "installed ~/$target"
        done

        if ! grep -q 'source.*\.bashrc' "$HOME/.bash_profile" 2>/dev/null; then
            cat >> "$HOME/.bash_profile" <<'PROFILE'

# Source .bashrc for login shells
if [[ -f "$HOME/.bashrc" ]]; then
    source "$HOME/.bashrc"
fi
PROFILE
        fi
    fi

    mkdir -p "$HOME/.vim/undodir"

    # Deploy neovim config only when nvim is installed.
    if command -v nvim &>/dev/null && [[ -f "$NOVASHELL_DIR/init.lua" ]]; then
        mkdir -p "$HOME/.config/nvim" "$HOME/.local/share/nvim/undo"
        if [[ -f "$HOME/.config/nvim/init.lua" ]] && ! head -5 "$HOME/.config/nvim/init.lua" 2>/dev/null | grep -q 'INIT.LUA - NovaShell'; then
            local nvbak="$HOME/.config/nvim/init.lua.pre-novashell.$(date +%Y%m%d%H%M%S)"
            cp -a "$HOME/.config/nvim/init.lua" "$nvbak"
            info "backed up existing nvim config → $nvbak"
        fi
        cp "$NOVASHELL_DIR/init.lua" "$HOME/.config/nvim/init.lua"
        chmod 644 "$HOME/.config/nvim/init.lua"
        ok "installed ~/.config/nvim/init.lua"
    fi

    rotate_backups

    local version="unknown"
    [[ -f "$NOVASHELL_DIR/VERSION" ]] && version=$(cat "$NOVASHELL_DIR/VERSION")
    if [[ "$MODE" == "prefix" ]]; then
        printf 'mode=prefix\nprefix=%s\nversion=%s\ninstalled=%s\nroot=%s\n' \
            "$PREFIX" "$version" "$(date -Iseconds)" "$NOVASHELL_DIR" > "$MARKER"
    else
        printf 'mode=native\nversion=%s\ninstalled=%s\nroot=%s\n' \
            "$version" "$(date -Iseconds)" "$NOVASHELL_DIR" > "$MARKER"
    fi

    echo ""
    if [[ "$MODE" == "prefix" ]]; then
        ok "NovaShell prefix '$PREFIX' enabled for $(whoami). Run 'source ~/${PREFIX}_bashrc'."
        info "Your ~/.bashrc was not modified."
    else
        ok "NovaShell enabled for $(whoami). Run 'source ~/.bashrc' or start a new shell."
    fi
    echo ""
    echo -e "  ${B}novashell status${N}   — show state"
    echo -e "  ${B}novashell disable${N}  — remove/restore"
    echo -e "  ${B}helpme${N}             — in-shell cheat sheet"
}

# ---- disable / restore ---------------------------------------------------------
do_disable() {
    resolve_paths

    if [[ "$MODE" == "prefix" ]]; then
        info "removing NovaShell prefix '$PREFIX' for $(whoami)"
        for src in "${!FILE_MAP[@]}"; do
            local target="${FILE_MAP[$src]}"
            if [[ -f "$HOME/$target" ]]; then
                rm -f "$HOME/$target"
                ok "removed ~/$target"
            fi
        done
        rm -f "$MARKER"
        ok "NovaShell prefix '$PREFIX' disabled. Your ~/.bashrc was never touched."
        return 0
    fi

    info "disabling NovaShell for $(whoami)"

    local last_backup=""
    if [[ -f "$HOME/.novashell_last_backup" ]]; then
        last_backup=$(cat "$HOME/.novashell_last_backup" 2>/dev/null || true)
    fi
    if [[ -z "$last_backup" ]] || [[ ! -d "$last_backup" ]]; then
        last_backup=$(ls -1dt "${BACKUP_BASE}"_* 2>/dev/null | head -1 || true)
    fi

    if [[ -n "$last_backup" ]] && [[ -d "$last_backup" ]]; then
        info "restoring from $last_backup"
        for f in "$last_backup"/.*; do
            [[ -f "$f" ]] || continue
            local fname=$(basename "$f")
            [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
            cp -a "$f" "$HOME/$fname"
            ok "restored $fname"
        done
    else
        warn "no backup directory found — removing installed files only"
        for src in "${!FILE_MAP[@]}"; do
            local target="${FILE_MAP[$src]}"
            if [[ -f "$HOME/$target" ]] && head -3 "$HOME/$target" 2>/dev/null | grep -q 'NovaShell'; then
                rm -f "$HOME/$target"
                ok "removed ~/$target"
            fi
        done
    fi

    rm -f "$MARKER" "$HOME/.novashell_last_backup"
    ok "NovaShell disabled. Start a new shell to take effect."
}

# ---- status -------------------------------------------------------------------
do_status() {
    resolve_paths
    echo -e "${C}NovaShell status for $(whoami)${N}"
    echo "  Package root:    $NOVASHELL_DIR"
    local version="unknown"
    [[ -f "$NOVASHELL_DIR/VERSION" ]] && version=$(cat "$NOVASHELL_DIR/VERSION")
    echo "  Package version: $version"
    [[ "$MODE" == "prefix" ]] && echo "  Query mode:      prefix '$PREFIX'"

    if [[ -f "$MARKER" ]]; then
        echo -e "  Opt-in state:    ${G}enabled${N}"
        sed 's/^/    /' "$MARKER"
    else
        if [[ "$MODE" == "prefix" ]]; then
            echo -e "  Opt-in state:    ${Y}disabled${N} (run 'novashell enable --prefix $PREFIX' to opt in)"
        else
            echo -e "  Opt-in state:    ${Y}disabled${N} (run 'novashell enable' to opt in)"
        fi
    fi

    # List every prefix install we can detect in $HOME (informational).
    local other
    mapfile -t other < <(ls -1 "$HOME"/*_installed 2>/dev/null | grep -v '\.novashell_installed$' || true)
    if [[ ${#other[@]} -gt 0 ]]; then
        echo "  Prefix installs detected:"
        local p
        for p in "${other[@]}"; do
            local pname
            pname=$(basename "$p" _installed)
            echo "    ~/${pname}_bashrc   marker: $p"
        done
    fi

    if [[ "$MODE" != "prefix" ]]; then
        local backups
        mapfile -t backups < <(ls -1dt "${BACKUP_BASE}"_* 2>/dev/null || true)
        echo "  Backups retained: ${#backups[@]}"
        local b
        for b in "${backups[@]:0:3}"; do echo "    $b"; done
    fi
}

# ---- update -------------------------------------------------------------------
do_update() {
    resolve_paths
    if [[ ! -f "$MARKER" ]]; then
        if [[ "$MODE" == "prefix" ]]; then
            die "prefix '$PREFIX' not currently enabled. Run 'novashell enable --prefix $PREFIX' first."
        fi
        die "not currently enabled — nothing to update. Run 'novashell enable' first."
    fi
    info "re-applying latest files from $NOVASHELL_DIR"
    do_install
}

# ---- help ---------------------------------------------------------------------
show_help() {
    cat <<EOF
NovaShell CLI — per-user opt-in management

Usage: novashell <command> [--prefix NAME]

Commands:
  enable    Install NovaShell config for the current user (with backup).
  disable   Restore original config files; remove opt-in marker.
  status    Show current install + opt-in state for the user.
  update    Re-apply package files (use after 'dnf update novashell').
  help      Show this help.

Options:
  --prefix NAME   Prefix mode: install as ~/NAME_bashrc (does NOT touch
                  ~/.bashrc). Lets one user run multiple prefixed installs
                  side by side, or opt in on a root account without clobbering
                  existing config. NAME must be alphanumeric and start with
                  a letter.

Examples:
  novashell enable                   # native: overwrites ~/.bashrc (with backup)
  novashell enable --prefix cf       # prefix mode: ~/cf_bashrc only
  novashell status --prefix cf       # show state for the 'cf' prefix
  novashell disable --prefix cf      # remove the 'cf' prefix install

Layout (native):
  $NOVASHELL_DIR/           ← system-wide package (read-only)
  ~/.bashrc, ~/.vimrc, …    ← copied here on 'enable'
  ~/.novashell_installed    ← opt-in marker
  ~/.novashell_backup_*/    ← rotated originals (keeps $KEEP_BACKUPS most recent)

Layout (prefix):
  ~/NAME_bashrc             ← entry point (source manually)
  ~/NAME_installed          ← marker for this prefix
  (no backup dir — ~/.bashrc is not touched)

Environment variables:
  NOVASHELL_DIR       Override package location.
  NOVASHELL_PROMPT    Select prompt: fancy (default) / minimal / pico / nova / dev.
  NOVASHELL_NO_WELCOME=1  Skip welcome screen.
EOF
}

parse_opts() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --prefix)
                [[ -z "${2:-}" ]] && die "--prefix requires a NAME argument"
                local pn="${2#.}"
                valid_prefix "$pn" || die "invalid prefix '$2' — must be alphanumeric, start with a letter"
                MODE="prefix"
                PREFIX="$pn"
                shift 2
                ;;
            --native)
                MODE="native"
                shift
                ;;
            *)
                die "unknown option: $1 (try 'novashell help')"
                ;;
        esac
    done
}

CMD="${1:-help}"
shift || true
parse_opts "$@"

case "$CMD" in
    enable)  do_install ;;
    disable|restore) do_disable ;;
    status)  do_status ;;
    update|reinstall) do_update ;;
    help|--help|-h) show_help ;;
    *) die "unknown command: $CMD (try 'novashell help')" ;;
esac
