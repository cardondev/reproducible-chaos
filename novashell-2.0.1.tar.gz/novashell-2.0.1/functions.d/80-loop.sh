# NovaShell functions.d/80-loop — SSH keep-alive.
#
# Simple while-loop alias. Refreshes the date in place on a single line.
# Ctrl+C exits and redraws the prompt.
#
# Works on RHEL 7/8/9/10 across SSH, PuTTY, mosh, and nested screen. Kept as
# an alias (not a function) by design so the shell parser never has to deal
# with `loop() {` on shells that already have a `loop` alias defined.

alias loop='while true; do printf "\r[loop keepalive] %s         " "$(date "+%Y-%m-%d %H:%M:%S %Z")"; sleep 60; done'
alias lp='loop'
