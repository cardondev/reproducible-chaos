#!/bin/bash
# DEPLOY - NovaShell

set -euo pipefail

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_PREFIX=".novashell"
BACKUP_DIR=""
INSTALL_MODE=""
PREFIX=""

# File mapping: source_name -> array of possible target names set during config
declare -A FILE_MAP

# Colors (256-color safe)
RED='\e[38;5;203m'
GREEN='\e[38;5;151m'
YELLOW='\e[38;5;223m'
BLUE='\e[38;5;111m'
CYAN='\e[38;5;116m'
MAGENTA='\e[38;5;183m'
PEACH='\e[38;5;216m'
RESET='\e[0m'
BOLD='\e[1m'

# -----------------------------------------------------------------------------
# Helper Functions
# -----------------------------------------------------------------------------
log_info()    { echo -e "${BLUE}[INFO]${RESET} $1"; }
log_success() { echo -e "${GREEN}[ OK ]${RESET} $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${RESET} $1"; }
log_error()   { echo -e "${RED}[ERR ]${RESET} $1"; }
log_section() { echo -e "\n${BOLD}${CYAN}=== $1 ===${RESET}\n"; }

confirm() {
    local prompt="${1:-Continue?}"
    read -p "$(echo -e "${YELLOW}$prompt [y/N]:${RESET} ")" -n 1 -r
    echo
    [[ $REPLY =~ ^[Yy]$ ]]
}

# -----------------------------------------------------------------------------
# Banner
# -----------------------------------------------------------------------------
show_banner() {
    echo -e "${BOLD}${CYAN}"
    cat << 'BANNER'
    _   __                 _____ __         ____
   / | / /___ _   ______ / ___// /_  ___  / / /
  /  |/ / __ \ | / / __ \\__ \/ __ \/ _ \/ / /
 / /|  / /_/ / |/ / /_/ /__/ / / / /  __/ / /
/_/ |_/\____/|___/\__,_/____/_/ /_/\___/_/_/

    v1.0
BANNER
    echo -e "${RESET}"
}

# -----------------------------------------------------------------------------
# System Detection
# -----------------------------------------------------------------------------
detect_system() {
    log_section "System Detection"

    if [[ -f /etc/redhat-release ]]; then
        log_info "OS: $(cat /etc/redhat-release)"
    elif [[ -f /etc/os-release ]]; then
        log_info "OS: $(grep PRETTY_NAME /etc/os-release | cut -d'"' -f2)"
    else
        log_warn "Unknown OS"
    fi

    log_info "Hostname: $(hostname)"
    log_info "User: $(whoami)"
    log_info "Home: $HOME"
    log_info "Shell: $SHELL"
    log_info "Bash: ${BASH_VERSION:-N/A}"

    # Check dependencies
    log_info "Checking dependencies..."
    local missing=()
    for cmd in vim bash; do
        command -v "$cmd" &>/dev/null || missing+=("$cmd")
    done

    for cmd in tmux fzf bat fd rg htop; do
        if command -v "$cmd" &>/dev/null; then
            log_success "$cmd: found"
        else
            log_warn "$cmd: not installed (optional)"
        fi
    done

    if [[ ${#missing[@]} -gt 0 ]]; then
        log_error "Missing required: ${missing[*]}"
        return 1
    fi
    log_success "All required dependencies found"
}

# -----------------------------------------------------------------------------
# Install Optional Dependencies
# -----------------------------------------------------------------------------
install_dependencies() {
    log_section "Optional Dependencies"

    if ! command -v dnf &>/dev/null && ! command -v yum &>/dev/null; then
        log_warn "No package manager found, skipping dependency install"
        return 0
    fi

    # Detect package manager and RHEL major version
    local pkg_mgr="dnf"
    command -v dnf &>/dev/null || pkg_mgr="yum"
    local rhel_ver=9
    if [[ -f /etc/redhat-release ]]; then
        rhel_ver=$(grep -oP '(?<=release )\d' /etc/redhat-release 2>/dev/null || echo 9)
    fi

    # Package availability varies by RHEL version
    # RHEL7: no bat, fd-find, or ripgrep in EPEL; tmux, fzf, htop available
    # RHEL8+: all packages available via EPEL
    local available_pkgs=()
    if [[ "$rhel_ver" -le 7 ]]; then
        available_pkgs=(tmux fzf htop)
        log_info "RHEL ${rhel_ver} detected: bat, fd-find, ripgrep not available in EPEL"
    else
        available_pkgs=(tmux fzf bat fd-find ripgrep htop)
    fi

    local to_install=()
    for pkg in "${available_pkgs[@]}"; do
        if ! rpm -q "$pkg" &>/dev/null 2>&1; then
            to_install+=("$pkg")
        fi
    done

    if [[ ${#to_install[@]} -eq 0 ]]; then
        log_success "All optional packages already installed"
        return 0
    fi

    echo "The following optional packages can be installed:"
    for pkg in "${to_install[@]}"; do
        echo -e "  ${CYAN}$pkg${RESET}"
    done
    echo ""

    if confirm "Install optional packages? (requires sudo)"; then
        # Ensure EPEL is available
        if ! rpm -q epel-release &>/dev/null 2>&1; then
            log_info "Installing EPEL repository..."
            sudo "$pkg_mgr" install -y epel-release &>/dev/null 2>&1 || log_warn "Could not install EPEL"
        fi

        for pkg in "${to_install[@]}"; do
            log_info "Installing $pkg..."
            if sudo "$pkg_mgr" install -y "$pkg" &>/dev/null 2>&1; then
                log_success "Installed: $pkg"
            else
                log_warn "Failed to install: $pkg (may require manual install)"
            fi
        done
    else
        log_info "Skipping optional packages"
    fi
}

# -----------------------------------------------------------------------------
# Mode Selection
# -----------------------------------------------------------------------------
select_mode() {
    log_section "Installation Mode"

    echo "Select installation mode:"
    echo ""
    echo -e "  ${CYAN}1) Native Mode${RESET} (Recommended for personal systems)"
    echo "     Overwrites .bashrc, .bash_profile, .vimrc, .tmux.conf"
    echo "     Uses .bash_aliases and .bash_functions"
    echo "     Original files are backed up with a restore script"
    echo ""
    echo -e "  ${CYAN}2) Prefix Mode${RESET} (Recommended for shared/managed systems)"
    echo "     Creates separate files like .novashell_bashrc"
    echo "     Adds a sourcing line to .bashrc (does not replace it)"
    echo "     Supports custom prefix names"
    echo ""

    while true; do
        read -p "$(echo -e "${CYAN}Select mode [1/2]:${RESET} ")" -n 1 -r mode_choice
        echo
        case "$mode_choice" in
            1) INSTALL_MODE="native"; log_info "Selected: Native Mode"; break ;;
            2) INSTALL_MODE="prefix"; log_info "Selected: Prefix Mode"; break ;;
            *) log_warn "Invalid choice. Enter 1 or 2." ;;
        esac
    done
}

# -----------------------------------------------------------------------------
# Configure Native Mode
# -----------------------------------------------------------------------------
configure_native() {
    log_section "Native Mode Configuration"

    INSTALL_MODE="native"
    PREFIX=""

    FILE_MAP=(
        ["bashrc"]=".bashrc"
        ["bash_profile"]=".bash_profile"
        ["aliases"]=".bash_aliases"
        ["functions"]=".bash_functions"
        ["vimrc"]=".vimrc"
        ["tmux.conf"]=".tmux.conf"
    )

    echo "The following files will be replaced:"
    for src in bashrc bash_profile aliases functions vimrc tmux.conf; do
        local target="${FILE_MAP[$src]}"
        echo -e "  ${YELLOW}~/${target}${RESET}"
    done
    echo ""
    echo -e "${RED}${BOLD}WARNING:${RESET} This will overwrite your existing novashell!"
    echo "Original files will be backed up with a restore script."
    echo ""

    if ! confirm "Proceed with native installation?"; then
        log_info "Installation cancelled"
        exit 0
    fi
}

# -----------------------------------------------------------------------------
# Configure Prefix Mode
# -----------------------------------------------------------------------------
configure_prefix() {
    log_section "Prefix Mode Configuration"

    INSTALL_MODE="prefix"

    echo "The prefix determines the naming convention for config files."
    echo "Examples:"
    echo -e "  ${CYAN}.novashell${RESET}  -> .novashell_bashrc, .novashell_vimrc, etc."
    echo -e "  ${CYAN}.novashell${RESET} -> .novashell_bashrc, .novashell_vimrc, etc."
    echo ""

    read -p "$(echo -e "${CYAN}Enter prefix [${DEFAULT_PREFIX}]:${RESET} ")" PREFIX
    PREFIX="${PREFIX:-$DEFAULT_PREFIX}"

    # Ensure prefix starts with a dot
    [[ "$PREFIX" != .* ]] && PREFIX=".$PREFIX"

    log_info "Using prefix: $PREFIX"

    FILE_MAP=(
        ["bashrc"]="${PREFIX}_bashrc"
        ["bash_profile"]="${PREFIX}_bash_profile"
        ["aliases"]="${PREFIX}_aliases"
        ["functions"]="${PREFIX}_functions"
        ["vimrc"]="${PREFIX}_vimrc"
        ["tmux.conf"]="${PREFIX}_tmux.conf"
    )
}

# -----------------------------------------------------------------------------
# Backup Existing Files
# -----------------------------------------------------------------------------
backup_existing() {
    log_section "Backing Up Existing Configuration"

    BACKUP_DIR="$HOME/.novashell_backup_$(date +%Y%m%d_%H%M%S)"
    local files_to_backup=()

    # Collect files that exist
    for src in "${!FILE_MAP[@]}"; do
        local target="${FILE_MAP[$src]}"
        [[ -f "$HOME/$target" ]] && files_to_backup+=("$target")
    done

    # Also backup .bashrc in prefix mode (we'll modify it)
    if [[ "$INSTALL_MODE" == "prefix" ]] && [[ -f "$HOME/.bashrc" ]]; then
        files_to_backup+=(".bashrc")
    fi

    # Remove duplicates
    local unique_files=($(printf '%s\n' "${files_to_backup[@]}" | sort -u))

    if [[ ${#unique_files[@]} -eq 0 ]]; then
        log_info "No existing files to backup"
        return 0
    fi

    mkdir -p "$BACKUP_DIR"
    log_info "Backing up ${#unique_files[@]} file(s)..."

    for f in "${unique_files[@]}"; do
        cp -a "$HOME/$f" "$BACKUP_DIR/"
        log_success "Backed up: ~/$f"
    done

    # Create restore script
    cat > "$BACKUP_DIR/restore.sh" << 'RESTORE_SCRIPT'
#!/bin/bash
# =============================================================================
# RESTORE - Restore novashell from backup
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN='\e[38;5;151m'
YELLOW='\e[38;5;223m'
RED='\e[38;5;203m'
CYAN='\e[38;5;116m'
RESET='\e[0m'

echo -e "${CYAN}=== NovaShell Restore ===${RESET}"
echo ""
echo "Backup location: $SCRIPT_DIR"
echo ""
echo "Files to restore:"

restored=0
for f in "$SCRIPT_DIR"/.*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] && continue
    [[ "$fname" == "restore.sh" ]] && continue
    echo -e "  ${YELLOW}$fname${RESET}"
done

# Also check non-hidden files
for f in "$SCRIPT_DIR"/*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "restore.sh" ]] && continue
    echo -e "  ${YELLOW}$fname${RESET}"
done

echo ""
read -p "$(echo -e "${YELLOW}Restore these files? [y/N]:${RESET} ")" -n 1 -r
echo

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Restore cancelled."
    exit 0
fi

for f in "$SCRIPT_DIR"/.*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] && continue
    [[ "$fname" == "restore.sh" ]] && continue
    cp -a "$f" "$HOME/$fname"
    echo -e "${GREEN}Restored: $fname${RESET}"
    ((restored++))
done

for f in "$SCRIPT_DIR"/*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "restore.sh" ]] && continue
    cp -a "$f" "$HOME/$fname"
    echo -e "${GREEN}Restored: $fname${RESET}"
    ((restored++))
done

echo ""
echo -e "${GREEN}Restored $restored file(s). Run 'source ~/.bashrc' to reload.${RESET}"
RESTORE_SCRIPT
    chmod +x "$BACKUP_DIR/restore.sh"
    log_success "Backup directory: $BACKUP_DIR"
    log_success "Restore script: $BACKUP_DIR/restore.sh"
}

# -----------------------------------------------------------------------------
# Install Files - Native Mode
# -----------------------------------------------------------------------------
install_native() {
    log_section "Installing Files (Native Mode)"

    # Install each file with NOVASHELL_MODE set
    for src in bashrc bash_profile aliases functions vimrc tmux.conf; do
        local src_file="$SCRIPT_DIR/$src"
        local target="${FILE_MAP[$src]}"

        if [[ ! -f "$src_file" ]]; then
            log_warn "Source not found: $src_file"
            continue
        fi

        # For bashrc, inject NOVASHELL_MODE and fix source paths
        if [[ "$src" == "bashrc" ]]; then
            sed \
                -e '/^export NOVASHELL_PREFIX=/c\export NOVASHELL_PREFIX=""' \
                -e '/^export VIMINIT=/c\export VIMINIT='"'"'let $MYVIMRC="$HOME/.vimrc" | source $MYVIMRC'"'"'' \
                -e 's/\${NOVASHELL_PREFIX}_aliases/.bash_aliases/g' \
                -e 's/\${NOVASHELL_PREFIX}_functions/.bash_functions/g' \
                -e 's/\${NOVASHELL_PREFIX}_vimrc/.vimrc/g' \
                -e 's/\${NOVASHELL_PREFIX}_tmux.conf/.tmux.conf/g' \
                -e '/^export NOVASHELL_PREFIX/a export NOVASHELL_MODE="native"' \
                "$src_file" > "$HOME/$target"
        elif [[ "$src" == "bash_profile" ]]; then
            cp "$src_file" "$HOME/$target"
        else
            # Replace prefix references for native mode
            sed \
                -e 's/\${NOVASHELL_PREFIX}_bashrc/.bashrc/g' \
                -e 's/\${NOVASHELL_PREFIX}_aliases/.bash_aliases/g' \
                -e 's/\${NOVASHELL_PREFIX}_functions/.bash_functions/g' \
                -e 's/\${NOVASHELL_PREFIX}_vimrc/.vimrc/g' \
                -e 's/\${NOVASHELL_PREFIX}_tmux.conf/.tmux.conf/g' \
                "$src_file" > "$HOME/$target"
        fi

        chmod 644 "$HOME/$target"
        log_success "Installed: ~/$target"
    done

    # Ensure .bash_profile sources .bashrc
    if ! grep -q "source.*\.bashrc" "$HOME/.bash_profile" 2>/dev/null; then
        cat >> "$HOME/.bash_profile" << 'PROFILE_APPEND'

# Source .bashrc for login shells
if [[ -f "$HOME/.bashrc" ]]; then
    source "$HOME/.bashrc"
fi
PROFILE_APPEND
        log_success "Ensured .bash_profile sources .bashrc"
    fi
}

# -----------------------------------------------------------------------------
# Install Files - Prefix Mode
# -----------------------------------------------------------------------------
install_prefix() {
    log_section "Installing Files (Prefix Mode: $PREFIX)"

    for src in bashrc bash_profile aliases functions vimrc tmux.conf; do
        local src_file="$SCRIPT_DIR/$src"
        local target="${FILE_MAP[$src]}"

        if [[ ! -f "$src_file" ]]; then
            log_warn "Source not found: $src_file"
            continue
        fi

        # Replace the default prefix with the chosen one
        sed "s/\${NOVASHELL_PREFIX:-.novashell}/${PREFIX}/g; s/\.novashell/${PREFIX}/g" \
            "$src_file" > "$HOME/$target"
        chmod 644 "$HOME/$target"
        log_success "Installed: ~/$target"
    done

    # Add sourcing block to .bashrc
    log_section "Shell Integration"

    local source_block="
# =============================================================================
# NovaShell Integration (added by deploy.sh)
# Prefix: $PREFIX
# =============================================================================
export NOVASHELL_PREFIX=\"$PREFIX\"
export NOVASHELL_MODE=\"prefix\"
export VIMINIT='let \$MYVIMRC=\"\$HOME/${PREFIX}_vimrc\" | source \$MYVIMRC'
if [[ -f \"\$HOME/${PREFIX}_bash_profile\" ]]; then
    source \"\$HOME/${PREFIX}_bash_profile\"
fi
if [[ -f \"\$HOME/${PREFIX}_bashrc\" ]]; then
    source \"\$HOME/${PREFIX}_bashrc\"
fi
# =============================================================================
"

    if grep -q "NOVASHELL_PREFIX=\"$PREFIX\"" "$HOME/.bashrc" 2>/dev/null; then
        log_warn "Integration block already exists in ~/.bashrc"
    else
        if confirm "Append sourcing block to ~/.bashrc?"; then
            # Backup .bashrc before modifying
            cp "$HOME/.bashrc" "$HOME/.bashrc.pre_novashell_$(date +%Y%m%d%H%M%S)" 2>/dev/null || true
            echo "$source_block" >> "$HOME/.bashrc"
            log_success "Added integration to ~/.bashrc"
        else
            log_info "Manual integration required. Add to ~/.bashrc:"
            echo -e "${CYAN}$source_block${RESET}"
        fi
    fi
}

# -----------------------------------------------------------------------------
# Verify Installation
# -----------------------------------------------------------------------------
verify_installation() {
    log_section "Verification"

    local all_ok=true
    for src in "${!FILE_MAP[@]}"; do
        local target="${FILE_MAP[$src]}"
        if [[ -f "$HOME/$target" ]]; then
            log_success "Found: ~/$target"
        else
            log_error "Missing: ~/$target"
            all_ok=false
        fi
    done

    # Create vim undo directory
    mkdir -p "$HOME/.vim/undodir" 2>/dev/null
    log_success "Created: ~/.vim/undodir"

    if [[ "$all_ok" == true ]]; then
        log_success "All files installed successfully"
    else
        log_error "Some files are missing"
        return 1
    fi
}

# -----------------------------------------------------------------------------
# Print Summary
# -----------------------------------------------------------------------------
print_summary() {
    log_section "Installation Complete!"

    echo -e "${GREEN}"
    echo "  ╔═══════════════════════════════════════════════════════════╗"
    echo "  ║  NovaShell installed successfully!                         ║"
    echo "  ╠═══════════════════════════════════════════════════════════╣"
    echo "  ║                                                           ║"

    if [[ "$INSTALL_MODE" == "native" ]]; then
        echo "  ║  Mode: Native (direct overwrite)                          ║"
        echo "  ║                                                           ║"
        echo "  ║  Files:                                                   ║"
        echo "  ║    ~/.bashrc          ~/.bash_profile                     ║"
        echo "  ║    ~/.bash_aliases    ~/.bash_functions                   ║"
        echo "  ║    ~/.vimrc           ~/.tmux.conf                        ║"
    else
        echo "  ║  Mode: Prefix ($PREFIX)                                   "
        echo "  ║                                                           ║"
        echo "  ║  Files:                                                   ║"
        for src in bashrc bash_profile aliases functions vimrc tmux.conf; do
            printf "  ║    ~/%s\n" "${FILE_MAP[$src]}"
        done
    fi

    echo "  ║                                                           ║"
    echo "  ╠═══════════════════════════════════════════════════════════╣"
    echo "  ║  Quick Start:                                             ║"
    echo "  ║    source ~/.bashrc       Reload configuration            ║"
    echo "  ║    helpme                 Show function reference          ║"
    echo "  ║    sysinfo                System information               ║"
    echo "  ║    healthcheck            Quick health check               ║"
    echo "  ║    loop                   Keep screen alive                ║"
    echo "  ║                                                           ║"

    if [[ -n "$BACKUP_DIR" ]] && [[ -d "$BACKUP_DIR" ]]; then
        echo "  ║  Backup:                                                  ║"
        echo "  ║    $BACKUP_DIR"
        echo "  ║    Restore: bash $BACKUP_DIR/restore.sh                   "
        echo "  ║                                                           ║"
    fi

    echo "  ╚═══════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
}

# -----------------------------------------------------------------------------
# Restore from Backup
# -----------------------------------------------------------------------------
restore_backup() {
    log_section "Restore from Backup"

    # Find available backups
    local backups=()
    for d in "$HOME"/.novashell_backup_*; do
        [[ -d "$d" ]] && [[ -f "$d/restore.sh" ]] && backups+=("$d")
    done

    if [[ ${#backups[@]} -eq 0 ]]; then
        log_error "No backup directories found in $HOME"
        log_info "Looking for: ~/.novashell_backup_*"
        return 1
    fi

    echo "Available backups:"
    echo ""
    local i=1
    for b in "${backups[@]}"; do
        local bname=$(basename "$b")
        local timestamp="${bname#.novashell_backup_}"
        local file_count=$(find "$b" -maxdepth 1 -type f ! -name "restore.sh" | wc -l)
        echo -e "  ${CYAN}$i)${RESET} $bname (${file_count} files)"

        # Show files in backup
        for f in "$b"/.*; do
            [[ -f "$f" ]] || continue
            local fname=$(basename "$f")
            [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
            echo "     $fname"
        done
        for f in "$b"/*; do
            [[ -f "$f" ]] || continue
            local fname=$(basename "$f")
            [[ "$fname" == "restore.sh" ]] && continue
            echo "     $fname"
        done
        echo ""
        ((i++))
    done

    read -p "$(echo -e "${CYAN}Select backup to restore [1-${#backups[@]}]:${RESET} ")" choice

    if [[ "$choice" -ge 1 ]] && [[ "$choice" -le ${#backups[@]} ]]; then
        local selected="${backups[$((choice-1))]}"
        log_info "Restoring from: $selected"
        bash "$selected/restore.sh"
    else
        log_error "Invalid selection"
        return 1
    fi
}

# -----------------------------------------------------------------------------
# Uninstall
# -----------------------------------------------------------------------------
uninstall() {
    log_section "Uninstall"

    echo "Select what to uninstall:"
    echo ""
    echo -e "  ${CYAN}1)${RESET} Native installation (.bashrc, .vimrc, etc.)"
    echo -e "  ${CYAN}2)${RESET} Prefix installation (specify prefix)"
    echo ""

    read -p "$(echo -e "${CYAN}Select [1/2]:${RESET} ")" -n 1 -r
    echo

    case "$REPLY" in
        1)
            local files=("$HOME/.bash_aliases" "$HOME/.bash_functions")
            echo ""
            echo -e "${RED}WARNING:${RESET} This will remove .bash_aliases and .bash_functions"
            echo "You should restore .bashrc, .bash_profile, .vimrc, .tmux.conf from backup"
            echo ""
            if confirm "Remove these files?"; then
                for f in "${files[@]}"; do
                    [[ -f "$f" ]] && rm "$f" && log_success "Removed: $f"
                done
                log_warn "Restore your original novashell using: deploy.sh restore"
            fi
            ;;
        2)
            read -p "$(echo -e "${CYAN}Enter prefix to remove [${DEFAULT_PREFIX}]:${RESET} ")" PREFIX
            PREFIX="${PREFIX:-$DEFAULT_PREFIX}"
            [[ "$PREFIX" != .* ]] && PREFIX=".$PREFIX"

            local files=(
                "$HOME/${PREFIX}_bashrc"
                "$HOME/${PREFIX}_bash_profile"
                "$HOME/${PREFIX}_aliases"
                "$HOME/${PREFIX}_functions"
                "$HOME/${PREFIX}_vimrc"
                "$HOME/${PREFIX}_tmux.conf"
            )

            echo ""
            echo "Files to remove:"
            for f in "${files[@]}"; do
                [[ -f "$f" ]] && echo -e "  ${YELLOW}$f${RESET}"
            done
            echo ""

            if confirm "Remove these files?"; then
                for f in "${files[@]}"; do
                    [[ -f "$f" ]] && rm "$f" && log_success "Removed: $f"
                done
                log_warn "Remember to remove the integration block from ~/.bashrc"
            fi
            ;;
        *)
            log_error "Invalid choice"
            ;;
    esac
}

# -----------------------------------------------------------------------------
# Help
# -----------------------------------------------------------------------------
show_help() {
    cat << EOF
NovaShell Deployment Script v1.0

Usage: $0 [command]

Commands:
  install     Install configuration files (default, interactive)
  restore     Restore from a previous backup
  uninstall   Remove configuration files
  help        Show this help message

Installation Modes:
  Native Mode   Overwrites .bashrc, .bash_profile, .vimrc, .tmux.conf
                Creates .bash_aliases, .bash_functions
                Best for personal systems

  Prefix Mode   Creates separate files (e.g., .novashell_bashrc)
                Adds sourcing line to .bashrc
                Best for shared systems or multiple configs

Features:
  - Automatic backup with restore script
  - PuTTY/ASCII fallback support
  - Catppuccin Mocha color theme
  - Optional dependency installation (fzf, bat, tmux, etc.)
  - Git-aware prompt with status indicators
  - FZF-powered search functions
  - System health check and info functions
  - Loop/keepalive to prevent screen sleep
  - Login session logging via bash_profile

Examples:
  $0                 # Interactive installation
  $0 install         # Same as above
  $0 restore         # Restore from backup
  $0 uninstall       # Remove configuration
EOF
}

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
main() {
    show_banner

    local command="${1:-install}"

    case "$command" in
        install)
            detect_system
            install_dependencies
            select_mode

            if [[ "$INSTALL_MODE" == "native" ]]; then
                configure_native
                backup_existing
                install_native
            else
                configure_prefix
                backup_existing
                install_prefix
            fi

            verify_installation
            print_summary
            ;;
        restore)
            restore_backup
            ;;
        uninstall)
            uninstall
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "Unknown command: $command"
            show_help
            exit 1
            ;;
    esac
}

main "$@"
