#!/bin/bash
# RPM-HELPER - NovaShell

set -euo pipefail

NOVASHELL_DIR="/usr/share/novashell"
BACKUP_DIR="$HOME/.novashell_backup_rpm"
MARKER="$HOME/.novashell_installed"

GREEN='\e[38;5;151m'
YELLOW='\e[38;5;223m'
CYAN='\e[38;5;116m'
RED='\e[38;5;203m'
RESET='\e[0m'

# Files: source name -> target in home directory
declare -A FILE_MAP=(
    ["bashrc"]=".bashrc"
    ["bash_profile"]=".bash_profile"
    ["aliases"]=".bash_aliases"
    ["functions"]=".bash_functions"
    ["vimrc"]=".vimrc"
    ["tmux.conf"]=".tmux.conf"
)

do_install() {
    echo -e "${CYAN}NovaShell: Installing for $(whoami)...${RESET}"

    # Backup existing files
    if [[ ! -d "$BACKUP_DIR" ]]; then
        mkdir -p "$BACKUP_DIR"
        for src in "${!FILE_MAP[@]}"; do
            local target="${FILE_MAP[$src]}"
            if [[ -f "$HOME/$target" ]]; then
                cp -a "$HOME/$target" "$BACKUP_DIR/$target"
                echo -e "${YELLOW}  Backed up: ~/$target${RESET}"
            fi
        done

        # Create restore script in backup dir
        cat > "$BACKUP_DIR/restore.sh" << 'RESTORE_EOF'
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Restoring original configuration..."
restored=0
for f in "$SCRIPT_DIR"/.*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
    cp -a "$f" "$HOME/$fname"
    echo "  Restored: $fname"
    ((restored++))
done
echo "Restored $restored file(s). Run 'source ~/.bashrc' to reload."
RESTORE_EOF
        chmod +x "$BACKUP_DIR/restore.sh"
        echo -e "${GREEN}  Backup saved: $BACKUP_DIR${RESET}"
    else
        echo -e "${YELLOW}  Backup already exists: $BACKUP_DIR (not overwriting)${RESET}"
    fi

    # Install NovaShell files (native mode)
    for src in "${!FILE_MAP[@]}"; do
        local target="${FILE_MAP[$src]}"
        local src_file="$NOVASHELL_DIR/$src"

        [[ ! -f "$src_file" ]] && continue

        if [[ "$src" == "bashrc" ]]; then
            sed \
                -e '/^export NOVASHELL_PREFIX=/c\export NOVASHELL_PREFIX=""' \
                -e '/^export VIMINIT=/c\export VIMINIT='"'"'let $MYVIMRC="$HOME/.vimrc" | source $MYVIMRC'"'"'' \
                -e 's/${NOVASHELL_PREFIX}_aliases/.bash_aliases/g' \
                -e 's/${NOVASHELL_PREFIX}_functions/.bash_functions/g' \
                -e 's/${NOVASHELL_PREFIX}_vimrc/.vimrc/g' \
                -e 's/${NOVASHELL_PREFIX}_tmux.conf/.tmux.conf/g' \
                -e '/^export NOVASHELL_PREFIX/a export NOVASHELL_MODE="native"' \
                "$src_file" > "$HOME/$target"
        elif [[ "$src" == "bash_profile" ]]; then
            cp "$src_file" "$HOME/$target"
        else
            sed \
                -e 's/${NOVASHELL_PREFIX}_bashrc/.bashrc/g' \
                -e 's/${NOVASHELL_PREFIX}_aliases/.bash_aliases/g' \
                -e 's/${NOVASHELL_PREFIX}_functions/.bash_functions/g' \
                -e 's/${NOVASHELL_PREFIX}_vimrc/.vimrc/g' \
                -e 's/${NOVASHELL_PREFIX}_tmux.conf/.tmux.conf/g' \
                "$src_file" > "$HOME/$target"
        fi

        chmod 644 "$HOME/$target"
        echo -e "${GREEN}  Installed: ~/$target${RESET}"
    done

    # Ensure bash_profile sources bashrc
    if ! grep -q "source.*\.bashrc" "$HOME/.bash_profile" 2>/dev/null; then
        cat >> "$HOME/.bash_profile" << 'PROFILE_EOF'

# Source .bashrc for login shells
if [[ -f "$HOME/.bashrc" ]]; then
    source "$HOME/.bashrc"
fi
PROFILE_EOF
    fi

    # Create vim undo dir
    mkdir -p "$HOME/.vim/undodir" 2>/dev/null

    # Mark as installed
    echo "$(date -Iseconds)" > "$MARKER"

    echo ""
    echo -e "${GREEN}NovaShell installed. Run 'source ~/.bashrc' to activate.${RESET}"
}

do_restore() {
    echo -e "${CYAN}NovaShell: Restoring original config for $(whoami)...${RESET}"

    if [[ ! -d "$BACKUP_DIR" ]]; then
        echo -e "${YELLOW}  No backup found at $BACKUP_DIR — nothing to restore.${RESET}"
        return 0
    fi

    local restored=0
    for f in "$BACKUP_DIR"/.*; do
        [[ -f "$f" ]] || continue
        local fname=$(basename "$f")
        [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
        cp -a "$f" "$HOME/$fname"
        echo -e "${GREEN}  Restored: $fname${RESET}"
        ((restored++))
    done

    # Clean up marker
    rm -f "$MARKER"

    if [[ $restored -eq 0 ]]; then
        echo -e "${YELLOW}  No files found in backup (was a fresh install).${RESET}"
        # Remove the NovaShell files since there's nothing to restore
        for src in "${!FILE_MAP[@]}"; do
            local target="${FILE_MAP[$src]}"
            if [[ -f "$HOME/$target" ]]; then
                rm -f "$HOME/$target"
                echo -e "${YELLOW}  Removed: ~/$target${RESET}"
            fi
        done
    fi

    echo -e "${GREEN}  Restore complete. Log back in or run 'source ~/.bashrc' to reload.${RESET}"
}

case "${1:-}" in
    install)  do_install ;;
    restore)  do_restore ;;
    *)
        echo "Usage: $0 {install|restore}"
        exit 1
        ;;
esac
