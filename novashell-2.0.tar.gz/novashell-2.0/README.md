# NovaShell v1.9

Terminal configuration for RHEL 7/8/9/10, Rocky Linux, AlmaLinux, and Fedora
systems. Catppuccin Mocha color theme with PuTTY/ASCII fallback support.
Gracefully degrades on systems without EPEL access.

## Files

| File | Description |
|---|---|
| `bashrc` | Main shell configuration. Catppuccin Mocha 256-color palette, truecolor prompt with animated arrows, PuTTY ASCII fallback, fzf/bat integration (when available). |
| `bash_profile` | Login shell hook. Captures full system snapshot (CPU, memory, disk, network, SELinux, failed services, zombies) to `~/.login_log/` on every login. Displays a color-coded summary. |
| `aliases` | 160+ command aliases organized by category: color output, modern tool replacements, directory listing/navigation, safety nets, networking, firewalld, DNF/YUM, systemd, process management, disk/filesystem, logs, user management, SELinux, SSH, docker/podman, tmux, and quick config editing. |
| `functions` | 40+ shell functions: system info, health checks, service management, archive extraction, file/directory search, fzf-powered tools (file opener, directory changer, process killer, history search), network utilities, log analysis, colorized man pages, keepalive loop, configuration management, and a help reference. |
| `vimrc` | Vim configuration. Full Catppuccin Mocha colorscheme via 256-color variables (no plugins required), relative line numbers, mode-aware status line, trailing whitespace highlighting, filetype-specific indentation, netrw file browser, and common keybindings. Compatible with vim 7.4+ (RHEL 7). |
| `tmux.conf` | Tmux configuration. Catppuccin Mocha status bar with session/user/host/load/date, prefix remapped to `Ctrl-a`, vim-style pane navigation, vi copy mode, mouse support, synchronize-panes toggle, and window swap bindings. |
| `deploy.sh` | Installer script. Supports native mode, prefix mode, restore from backup, and uninstall. |

## Requirements

- bash 4.0+
- vim 7.4+
- tmux 2.1+ (optional)

No plugins, package managers, or external dependencies are required. Everything is self-contained.

## Optional Tools

These are **not required** but will be detected and used automatically if installed:

- `fzf` — fuzzy finder (enables `fo`, `fcd`, `fkill`, `fhist`, `dsh` functions and Ctrl-R/Ctrl-T bindings)
- `bat` — syntax-highlighted cat replacement (used in fzf previews and aliased to `cat`)
- `fd` — fast file finder (used by fzf for file/directory discovery)
- `ripgrep` — fast grep replacement
- `htop` — interactive process viewer (aliased to `top`)

The deploy script will offer to install these via `dnf` if they are not present.

## Deployment

Copy the NovaShell folder to the target system and run the deploy script:

```bash
bash deploy.sh
```

### Installation Modes

The script will prompt you to choose a mode:

#### 1. Native Mode

Overwrites standard shell config files directly. Best for personal systems.

```
~/.bashrc          <- Main shell config
~/.bash_profile    <- Login session capture
~/.bash_aliases    <- Command aliases
~/.bash_functions  <- Shell functions
~/.vimrc           <- Vim config
~/.tmux.conf       <- Tmux config
```

Original files are backed up before overwrite. A restore script is created in the backup directory.

#### 2. Prefix Mode

Creates separate files with a custom prefix. Best for shared or managed systems where you don't want to replace the default `.bashrc`.

When prompted, enter a prefix name (e.g., `novashell`):

```
~/.novashell_bashrc
~/.novashell_bash_profile
~/.novashell_aliases
~/.novashell_functions
~/.novashell_vimrc
~/.novashell_tmux.conf
```

A sourcing block is appended to `~/.bashrc` to load the prefixed config. The original `.bashrc` is not replaced.

### Restore from Backup

To restore your original configuration from a previous backup:

```bash
bash deploy.sh restore
```

### Uninstall

```bash
bash deploy.sh uninstall
```

## RPM Installation

Pre-built RPMs are available for RHEL 7, 8, 9, and 10:

```bash
sudo dnf install novashell-1.4-1.el9.noarch.rpm
```

The RPM installs in native mode automatically, backs up existing configs, and restores them on removal.

To build RPMs from source:

```bash
bash rpm/build-rpm.sh
```

## Prompt

The prompt is a three-line layout with animated italic arrows:

```
════════════════════════════════════════════════════════════════════
┌─[14:30:05 EDT]─[Wednesday, March 25, 2026]─[helios@server01.prod.example.com]
├─[~/projects/novashell]
└─❯❯❯
```

| Element | Color | Hex |
|---|---|---|
| Brackets, separator line, box drawing | Warm yellow | `#f9e2af` |
| Time | Sky blue | `#89dceb` |
| Date | Peach | `#fab387` |
| Username | Green | `#a6d189` |
| Hostname (FQDN) | Teal | `#94e2d5` |
| Path | Bright green | `#b8e994` |
| Prompt arrows | Light text, italic | `#cdd6f4` |
| Root username | Red + blink | `#f38ba8` |

On terminals without Unicode support (PuTTY), all special characters fall back to ASCII equivalents automatically.

## Key Aliases

| Alias | Command |
|---|---|
| `ll` | `ls -lAhF --group-directories-first` |
| `sts` | `systemctl status` |
| `srt` | `sudo systemctl start` |
| `srs` | `sudo systemctl restart` |
| `slog` | `journalctl -u` |
| `update` | `sudo dnf update -y` |
| `ports` | `ss -tulpn` |
| `loop` | Print time every 60s to prevent screen sleep |
| `reload` | `source ~/.bashrc` |
| `c` | `clear` |
| `vbash` | Edit bashrc in vim |
| `valias` | Edit aliases in vim |
| `vfunc` | Edit functions in vim |

Full alias list: run `alias` or read the `aliases` file.

## Key Functions

| Function | Usage | Description |
|---|---|---|
| `sysinfo` | `sysinfo` | Full system information display |
| `healthcheck` | `healthcheck` | Color-coded health check (load, memory, disk, services, SELinux, zombies) |
| `svc` | `svc nginx restart` | Service management helper (status, start, stop, restart, enable, disable, log) |
| `loop` | `loop` or `loop 30` | Keep screen alive, prints timestamp at interval (default 60s) |
| `extract` | `extract file.tar.gz` | Extract any archive format (tar, zip, 7z, rpm, xz, zst, etc.) |
| `mkcd` | `mkcd newdir` | Create directory and cd into it |
| `mkbak` | `mkbak file.conf` | Create timestamped backup of a file |
| `ff` | `ff config` | Find files by name pattern |
| `ftext` | `ftext "TODO"` | Search file contents recursively |
| `bigfiles` | `bigfiles 100M` | Find files larger than size |
| `portcheck` | `portcheck host 443` | Check if a port is open |
| `portscan` | `portscan host 1 1024` | Scan a port range |
| `certinfo` | `certinfo example.com` | Show TLS certificate details |
| `usercheck` | `usercheck admin` | Display user info, groups, last login |
| `logsearch` | `logsearch error` | Search system logs for a pattern |
| `errorlog` | `errorlog 50` | Show recent errors from journal |
| `man` | `man bash` | Colorized man pages |
| `helpme` | `helpme` | Quick reference of all functions |

### FZF-Powered Functions (require fzf)

| Function | Description |
|---|---|
| `fo` | Fuzzy find and open a file in vim with bat preview |
| `fcd` | Fuzzy find and cd into a directory |
| `fkill` | Fuzzy find and kill a process |
| `fhist` | Fuzzy search command history |
| `dsh` | Fuzzy select a running container and shell into it |

## Vim Keybindings

| Key | Mode | Action |
|---|---|---|
| `Space` | Leader | Leader key |
| `Space w` | Normal | Save file |
| `Space q` | Normal | Quit |
| `Space Space` | Normal | Clear search highlight |
| `Space e` | Normal | Toggle file browser (netrw) |
| `Space n` | Normal | Toggle line numbers |
| `Space l` | Normal | Toggle invisible characters |
| `Space W` | Normal | Strip trailing whitespace |
| `Ctrl-h/j/k/l` | Normal | Navigate between splits |
| `Tab / Shift-Tab` | Normal | Next/previous tab |
| `Alt-j / Alt-k` | Normal/Visual | Move lines up/down |
| `< / >` | Visual | Indent and keep selection |
| `jk` | Insert | Escape to normal mode |
| `F2` | Any | Toggle paste mode |

## Tmux Keybindings

Prefix is `Ctrl-a` (not the default `Ctrl-b`).

| Key | Action |
|---|---|
| `Prefix \|` | Split pane horizontally |
| `Prefix -` | Split pane vertically |
| `Prefix h/j/k/l` | Navigate panes (vim-style) |
| `Alt-Arrow` | Navigate panes (no prefix needed) |
| `Prefix H/J/K/L` | Resize panes |
| `Shift-Left/Right` | Previous/next window (no prefix needed) |
| `Prefix < / >` | Swap window left/right |
| `Prefix y` | Toggle synchronize-panes |
| `Prefix b` | Toggle status bar |
| `Prefix c` | New window (current path) |
| `Prefix C` | New window (prompted name) |
| `Prefix r` | Reload config |
| `Prefix Escape` | Enter copy mode |
| `v` | Begin selection (copy mode) |
| `y` | Copy selection (copy mode) |

## Login Session Logging

The `bash_profile` captures a full system snapshot on every login to `~/.login_log/login_YYYYMM.log`. Each entry records:

- Timestamp, user, host, terminal, SSH client
- OS, kernel, architecture, uptime
- CPU model, core count, load average
- Memory usage
- Disk usage for all mounted devices
- Network interfaces and IP addresses
- SELinux status
- Failed service count
- Zombie process count

Logs rotate monthly by filename.

## Compatibility

| System | Status |
|---|---|
| RHEL 7, 8, 9, 10 | Supported |
| Rocky Linux 8, 9 | Supported |
| AlmaLinux 8, 9, 10 | Supported |
| Fedora 38+ | Supported |
| PuTTY | Supported (ASCII fallback) |
| Windows Terminal | Supported (truecolor) |
| macOS Terminal | Supported |
| xterm / rxvt | Supported |

## License

MIT
