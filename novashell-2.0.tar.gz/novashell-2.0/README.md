# NovaShell v2.0

Terminal configuration for RHEL 7/8/9/10, Rocky Linux 8/9/10, AlmaLinux, and
Fedora. Catppuccin Mocha theme. PuTTY / ASCII fallback. Modular
`aliases.d` / `functions.d` / `prompts` trees. Five prompt styles. Per-user
opt-in when installed via RPM (shared-environment friendly).

## What's new in v2.0

- **Modular tree** — `aliases.d/` + `functions.d/` + `prompts/` (20+ files
  each, sorted load order). Easier to extend, test, and prune.
- **Five prompts** (git-free, per v1.3 perf contract):
  - `fancy` — original three-line animated layout (default)
  - `minimal` / `lowkey` — clean `host >`
  - `pico` — compact `user@host cwd λ` with exit-code badge
  - `nova` — two-line, powerline-style, right-aligned segments
    (venv / k8s / ssh / jobs / tmux / exit / time)
  - `dev` — engineer's daily driver with venv/k8s/tmux/ssh cluster
- **Opt-in RPM** — `dnf install novashell-2.0-*.rpm` does *not* modify any
  user's config. Each user runs `novashell enable` independently. Fixes the
  v1.x root-vs-user collision bug.
- **Cleanup on redeploy** — rotates old `.novashell_backup_*` (keeps 3
  most recent), removes orphaned prefix-mode files when switching layouts,
  never touches files lacking the NovaShell sentinel.
- **Hardened loop** — `while true; do …; sleep; done` with `\r\033[2K` for
  true in-place single-line refresh, plus `trap SIGINT` for clean Ctrl+C.
- **Neovim upgrades** (RHEL 9/10) — `:Grep`, `:Fzf` floating-terminal
  picker, `:Trim`, terminal-mode `Esc`, optional LSP (bash/lua) and
  treesitter — all guarded by executable/version checks, no network, no
  plugin manager.

## Source layout

```
src/
├── bashrc                 Entry point (sources all .d trees)
├── bash_profile           Login session logger
├── vimrc                  Vim + Catppuccin (RHEL 7 compatible)
├── tmux.conf              Tmux status bar + vim-style keys
├── init.lua               Neovim config (deployed only if nvim present)
├── deploy.sh              Tarball installer
├── novashell-cli.sh       /usr/bin/novashell (per-user opt-in CLI)
├── profile.d-novashell.sh /etc/profile.d hint script
├── aliases.d/             22 domain-split alias files
├── functions.d/           18 function modules
└── prompts/               7 prompt files (core + 5 styles + aliases)
```

## Compatibility

| System                   | Support          | Notes                                    |
|--------------------------|------------------|------------------------------------------|
| RHEL 7                   | Full             | Base repo only unless EPEL is present    |
| RHEL 8 / Rocky 8         | Full             | AppStream + EPEL                          |
| RHEL 9 / Rocky 9         | Full             | AppStream + EPEL; nvim auto-detected     |
| RHEL 10 / Rocky 10       | Full             | AppStream + EPEL; nvim auto-detected     |
| AlmaLinux 8/9/10         | Full             | Same as RHEL/Rocky                        |
| Fedora 38+               | Works            | Not primary target                        |
| PuTTY                    | Full             | ASCII fallback for prompts and tmux      |

## Installation

### RPM (recommended — opt-in per user)

```bash
sudo dnf install ./novashell-2.0-1.el9.noarch.rpm
novashell enable           # opt in for current user (creates backup)
source ~/.bashrc           # or log out / log back in
```

Each user opts in independently. Root can `sudo novashell enable` after
a regular user has already opted in — no collision.

Other commands:

```bash
novashell status           # show install + opt-in state
novashell update           # re-apply after `dnf update novashell`
novashell disable          # restore originals from backup
```

### Tarball / source

```bash
tar xzf novashell-2.0.tar.gz
cd novashell-2.0
bash src/deploy.sh                # install
bash src/deploy.sh restore        # restore originals
bash src/deploy.sh uninstall      # remove + restore
```

## Prompts

Switch at any time:

```bash
fancypants     # fancy (default)
lowkey         # minimal
pico           # compact one-line
nova           # two-line with context segments
dev            # dev workflow (venv/k8s/tmux)
promptname     # show current
```

Persist via `export NOVASHELL_PROMPT=<name>` in your shell.

## Key functions

| Function    | Description                                      |
|-------------|--------------------------------------------------|
| `sysinfo`   | Full system snapshot                             |
| `healthcheck` | Color-coded health check                        |
| `svc`       | Service management helper                        |
| `loop`      | In-place SSH keepalive, trap-on-INT             |
| `extract`   | Extract any archive format                       |
| `mkcd`, `mkbak`, `tmpd`, `up` | Directory helpers               |
| `ff`, `fdir`, `ftext`, `bigfiles`, `extcount` | Search            |
| `fo`, `fcd`, `fkill`, `fhist`, `dsh`, `fssh`, `fsvc` | fzf-powered |
| `portcheck`, `portscan`, `certinfo`, `sshtest`, `httping` | Net    |
| `genpass`, `serve`, `packageof`, `stripcolors`, `prettyjson`, `timer` | Misc |
| `urlencode`, `urldecode`                                  |         |
| `usercheck`, `logsearch`, `errorlog`, `note`, `notee`     |         |
| `helpme`    | In-shell cheat sheet                             |

## Requirements

- bash 4.0+
- vim 7.4+ (RHEL 7 ships 7.4.160; vimrc is version-guarded)
- tmux 2.1+ (optional)

Everything else is optional auto-detected: `fzf`, `bat`, `fd`, `ripgrep`,
`htop`, `nvim`.

RHEL 7 deploys native-repo only unless EPEL is configured. RHEL 8+
uses AppStream + EPEL.

## License

MIT
