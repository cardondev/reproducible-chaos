# /etc/profile.d/novashell.sh — installed by the RPM.
#
# Does NOT load NovaShell. The package is explicitly opt-in per user because
# this is typically deployed in shared environments.
#
# On interactive login, if the user has NOT run `novashell enable`, print a
# one-time hint (rate-limited to once per 24h per user via a stamp file).
# Never interferes with scripted/non-interactive shells.

# Only act on interactive shells
case "$-" in *i*) ;; *) return 0 ;; esac

# Skip if already opted in
[[ -f "$HOME/.novashell_installed" ]] && return 0

# Skip if user has silenced the hint
[[ -f "$HOME/.novashell_nohint" ]] && return 0

# Rate-limit the hint
_ns_hint_stamp="$HOME/.cache/novashell_hint"
mkdir -p "$HOME/.cache" 2>/dev/null || true
if [[ -f "$_ns_hint_stamp" ]]; then
    _ns_hint_age=$(( $(date +%s) - $(stat -c %Y "$_ns_hint_stamp" 2>/dev/null || echo 0) ))
    [[ $_ns_hint_age -lt 86400 ]] && { unset _ns_hint_age _ns_hint_stamp; return 0; }
fi
touch "$_ns_hint_stamp" 2>/dev/null || true
unset _ns_hint_age _ns_hint_stamp

printf '\e[38;5;116m[novashell]\e[0m installed system-wide. Run \e[38;5;223mnovashell enable\e[0m to opt in, or \e[38;5;243mtouch ~/.novashell_nohint\e[0m to silence this message.\n'
