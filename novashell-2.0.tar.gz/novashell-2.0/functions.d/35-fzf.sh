# NovaShell functions.d/35-fzf — fzf-powered tools (only if fzf is installed)

if command -v fzf &>/dev/null; then
    fo() {
        local file
        file=$(fzf --preview 'bat --color=always --style=numbers --line-range :500 {} 2>/dev/null || head -500 {}' --preview-window=right:60%)
        [[ -n "$file" ]] && ${EDITOR:-vim} "$file"
    }

    fcd() {
        local dir
        if command -v fd &>/dev/null; then
            dir=$(fd --type d --hidden --follow --exclude .git 2>/dev/null | fzf --height 40% --reverse --preview 'ls -la --color=always {}')
        else
            dir=$(find . -type d 2>/dev/null | fzf --height 40% --reverse --preview 'ls -la --color=always {}')
        fi
        [[ -n "$dir" ]] && cd "$dir"
    }

    fkill() {
        local pid
        pid=$(ps aux | sed '1d' | fzf --height 40% --multi | awk '{print $2}')
        [[ -n "$pid" ]] && echo "$pid" | xargs kill -${1:-9}
    }

    fhist() {
        local cmd
        cmd=$(history | awk '{$1=""; print substr($0,2)}' | sort -u | fzf --height 40% --reverse --tac --query "$*")
        if [[ -n "$cmd" ]]; then
            echo "$cmd"
            eval "$cmd"
        fi
    }

    dsh() {
        local container
        container=$(docker ps --format '{{.Names}}' 2>/dev/null | fzf --height 40% --reverse)
        [[ -n "$container" ]] && docker exec -it "$container" "${1:-/bin/bash}"
    }

    # fssh — fuzzy-pick host from ~/.ssh/config and ssh into it
    fssh() {
        local host
        host=$(awk '/^Host / && $2 !~ /\*/ {print $2}' ~/.ssh/config 2>/dev/null | fzf --height 40% --reverse --prompt='ssh> ')
        [[ -n "$host" ]] && ssh "$host"
    }

    # fsvc — fuzzy-pick a systemd unit, then pick an action
    fsvc() {
        local unit action
        unit=$(systemctl list-units --type=service --all --no-legend 2>/dev/null | awk '{print $1}' | fzf --height 40% --reverse --prompt='svc> ')
        [[ -z "$unit" ]] && return
        action=$(printf 'status\nstart\nstop\nrestart\nreload\nenable\ndisable\nlog\n' | fzf --height 40% --reverse --prompt='action> ')
        [[ -n "$action" ]] && svc "$unit" "$action"
    }
fi
