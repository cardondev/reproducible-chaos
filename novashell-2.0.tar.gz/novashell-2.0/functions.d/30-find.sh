# NovaShell functions.d/30-find — find/search helpers

ff()       { find . -type f -iname "*$1*" 2>/dev/null; }
fdir()     { find . -type d -iname "*$1*" 2>/dev/null; }
ftext()    { grep -rn --color=auto "$1" . 2>/dev/null; }
bigfiles() { local size="${1:-100M}"; find . -type f -size "+$size" -exec ls -lh {} \; 2>/dev/null | sort -k5 -h; }
oldfiles() { local days="${1:-30}"; find . -type f -mtime "+$days" -exec ls -lh {} \; 2>/dev/null; }
dirsize()  { du -sh "${1:-.}"/* 2>/dev/null | sort -rh | head -20; }

# Count files by extension in current tree (no deps, works RHEL 7-10).
extcount() {
    find "${1:-.}" -type f 2>/dev/null | awk -F. 'NF>1{print tolower($NF)}' | sort | uniq -c | sort -rn
}
