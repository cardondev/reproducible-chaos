# NovaShell functions.d/15-archive — archive extract/pack

extract() {
    [[ -z "$1" ]] && { echo "Usage: extract <archive>"; return 1; }
    [[ ! -f "$1" ]] && { echo "'$1' is not a valid file"; return 1; }
    case "$1" in
        *.tar.bz2)   tar xjf "$1"     ;;
        *.tar.gz)    tar xzf "$1"     ;;
        *.tar.xz)    tar xJf "$1"     ;;
        *.tar.zst)   tar --zstd -xf "$1" ;;
        *.bz2)       bunzip2 "$1"     ;;
        *.rar)       unrar x "$1"     ;;
        *.gz)        gunzip "$1"      ;;
        *.tar)       tar xf "$1"      ;;
        *.tbz2)      tar xjf "$1"     ;;
        *.tgz)       tar xzf "$1"     ;;
        *.zip)       unzip "$1"       ;;
        *.Z)         uncompress "$1"  ;;
        *.7z)        7z x "$1"        ;;
        *.xz)        xz -d "$1"       ;;
        *.lzma)      lzma -d "$1"     ;;
        *.zst)       zstd -d "$1"     ;;
        *.rpm)       rpm2cpio "$1" | cpio -idmv ;;
        *)           echo "'$1' cannot be extracted via extract()" ;;
    esac
}

mktar() { [[ -z "$1" ]] && { echo "Usage: mktar <dir>"; return 1; }; tar cvf  "${1%%/}.tar"     "$1"; }
mktgz() { [[ -z "$1" ]] && { echo "Usage: mktgz <dir>"; return 1; }; tar czvf "${1%%/}.tar.gz"  "$1"; }
mktbz() { [[ -z "$1" ]] && { echo "Usage: mktbz <dir>"; return 1; }; tar cjvf "${1%%/}.tar.bz2" "$1"; }
mktzst() { [[ -z "$1" ]] && { echo "Usage: mktzst <dir>"; return 1; }; tar --zstd -cvf "${1%%/}.tar.zst" "$1"; }
