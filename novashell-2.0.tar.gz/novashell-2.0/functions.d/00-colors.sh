# NovaShell functions.d/00-colors — color definitions for functions
# These are plain ANSI (no \[\] wrappers) for echo/printf use.

_C_RESET='\e[0m'
_C_BOLD='\e[1m'
_C_RED='\e[38;5;203m'
_C_GREEN='\e[38;5;151m'
_C_YELLOW='\e[38;5;223m'
_C_BLUE='\e[38;5;111m'
_C_CYAN='\e[38;5;116m'
_C_MAGENTA='\e[38;5;183m'
_C_PEACH='\e[38;5;216m'
