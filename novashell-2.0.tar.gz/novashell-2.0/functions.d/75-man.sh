# NovaShell functions.d/75-man — colorized man pages

man() {
    LESS_TERMCAP_mb=$'\e[1;38;5;203m' \
    LESS_TERMCAP_md=$'\e[1;38;5;111m' \
    LESS_TERMCAP_me=$'\e[0m' \
    LESS_TERMCAP_se=$'\e[0m' \
    LESS_TERMCAP_so=$'\e[1;38;5;235;48;5;183m' \
    LESS_TERMCAP_ue=$'\e[0m' \
    LESS_TERMCAP_us=$'\e[4;38;5;151m' \
    command man "$@"
}

# Tree fallback (no package dep; works RHEL 7 w/o `tree` installed).
if ! command -v tree &>/dev/null; then
    tree() {
        find "${1:-.}" -print | sed -e 's;[^/]*/;|   ;g;s;|   \([^|]\);|-- \1;'
    }
fi
