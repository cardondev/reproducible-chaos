# NovaShell functions.d/55-misc — grab-bag utilities (dependency-free)

# Random password. /dev/urandom + tr — works RHEL 7-10, no openssl/pwgen.
genpass() {
    local len="${1:-20}"
    if ! [[ "$len" =~ ^[0-9]+$ ]] || [[ "$len" -lt 4 ]]; then
        echo "Usage: genpass [length>=4]" >&2
        return 1
    fi
    LC_ALL=C tr -dc 'A-Za-z0-9!@#%^&*_+=' </dev/urandom | head -c "$len"
    echo
}

# Quick python http server. RHEL 7 ships python2; 8+ ships python3.
serve() {
    local port="${1:-8000}" host="${2:-0.0.0.0}"
    if command -v python3 &>/dev/null; then
        echo "Serving $PWD on http://${host}:${port}/  (Ctrl+C to stop)"
        python3 -m http.server --bind "$host" "$port"
    elif command -v python2 &>/dev/null; then
        echo "Serving $PWD on http://${host}:${port}/  (Ctrl+C to stop)"
        python2 -m SimpleHTTPServer "$port"
    else
        echo "No python found" >&2
        return 1
    fi
}

# Which RPM owns this file/command?
packageof() {
    [[ -z "$1" ]] && { echo "Usage: packageof <file>"; return 1; }
    local target="$1"
    if [[ "$target" != */* ]] && ! [[ -e "$target" ]]; then
        target=$(command -v "$target" 2>/dev/null || echo "$target")
    fi
    rpm -qf "$target"
}

# Strip ANSI color codes from stdin or a file.
stripcolors() {
    if [[ -n "$1" ]]; then
        sed 's/\x1B\[[0-9;]*[mGKHF]//g' "$1"
    else
        sed 's/\x1B\[[0-9;]*[mGKHF]//g'
    fi
}

# URL encode/decode (no python3 dep on RHEL 7 via -n).
urlencode() {
    local s="$*" i c out=""
    for (( i=0; i<${#s}; i++ )); do
        c="${s:$i:1}"
        case "$c" in [a-zA-Z0-9.~_-]) out+="$c" ;; *) out+=$(printf '%%%02X' "'$c") ;; esac
    done
    printf '%s\n' "$out"
}
urldecode() { printf '%b\n' "$(sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g' <<< "$*")"; }

# Nicely-formatted JSON if python3 is available; otherwise raw.
prettyjson() {
    if command -v jq &>/dev/null; then
        jq . "${1:-/dev/stdin}"
    elif command -v python3 &>/dev/null; then
        python3 -m json.tool "${1:-/dev/stdin}"
    else
        cat "${1:-/dev/stdin}"
    fi
}

# Quick timer. `timer 10 echo done` runs cmd after 10s, prints countdown.
timer() {
    local secs="${1:-5}"; shift
    while (( secs > 0 )); do
        printf "\r${_C_YELLOW}[timer] %ds${_C_RESET}  " "$secs"
        sleep 1
        (( secs-- ))
    done
    printf "\r${_C_GREEN}[timer] done        ${_C_RESET}\n"
    [[ $# -gt 0 ]] && "$@"
}
