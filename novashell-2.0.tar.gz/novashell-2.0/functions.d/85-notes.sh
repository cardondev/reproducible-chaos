# NovaShell functions.d/85-notes — quick notes

note() {
    local note_dir="$HOME/.notes"
    mkdir -p "$note_dir"
    if [[ -z "$1" ]]; then
        ls -1t "$note_dir" 2>/dev/null | head -20
        [[ -f "$note_dir/notes.md" ]] && { echo ""; tail -20 "$note_dir/notes.md"; }
    else
        echo "$(date '+%Y-%m-%d %H:%M:%S') - $*" >> "$note_dir/notes.md"
        echo "Note saved."
    fi
}

# Edit notes.md in $EDITOR.
notee() { ${EDITOR:-vim} "$HOME/.notes/notes.md"; }
