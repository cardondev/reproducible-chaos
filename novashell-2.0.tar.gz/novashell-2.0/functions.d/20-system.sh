# NovaShell functions.d/20-system — sysinfo + healthcheck + svc helper

calc() { echo "scale=4; $*" | bc -l; }

sysinfo() {
    echo -e "${_C_CYAN}Hostname:${_C_RESET}     $(hostname -f 2>/dev/null || hostname)"
    echo -e "${_C_CYAN}Kernel:${_C_RESET}       $(uname -r)"
    echo -e "${_C_CYAN}Architecture:${_C_RESET} $(uname -m)"
    echo -e "${_C_CYAN}Uptime:${_C_RESET}       $(uptime -p 2>/dev/null || uptime | awk -F'up ' '{print $2}' | awk -F',' '{print $1}')"
    echo -e "${_C_CYAN}Date/Time:${_C_RESET}    $(date '+%Y-%m-%d %H:%M:%S %Z')"

    if [[ -f /etc/redhat-release ]]; then
        echo -e "${_C_CYAN}OS Release:${_C_RESET}   $(cat /etc/redhat-release)"
    elif [[ -f /etc/os-release ]]; then
        echo -e "${_C_CYAN}OS Release:${_C_RESET}   $(grep PRETTY_NAME /etc/os-release | cut -d'"' -f2)"
    fi

    echo -e "\n${_C_CYAN}IP Addresses:${_C_RESET}"
    ip -4 addr show 2>/dev/null | awk '/inet / && !/127.0.0.1/ {gsub(/\/.*/, "", $2); printf "  %-12s %s\n", $NF":", $2}'

    echo -e "\n${_C_CYAN}Memory:${_C_RESET}"
    free -h | awk '/^Mem:/ {printf "  Total: %s  Used: %s  Free: %s  Available: %s\n", $2, $3, $4, $7}'

    echo -e "\n${_C_CYAN}Disk Usage:${_C_RESET}"
    df -hT 2>/dev/null | awk 'NR==1 || /^\/dev/' | head -6

    echo -e "\n${_C_CYAN}Load Average:${_C_RESET} $(awk '{print $1, $2, $3}' /proc/loadavg)"
    echo -e "\n${_C_CYAN}SELinux:${_C_RESET}      $(getenforce 2>/dev/null || echo 'N/A')"

    echo -e "\n${_C_CYAN}Top 5 CPU Processes:${_C_RESET}"
    ps aux --sort=-%cpu 2>/dev/null | awk 'NR>1 && NR<=6 {printf "  %-8s %5s%%  %s\n", $1, $3, $11}'

    echo -e "\n${_C_CYAN}Top 5 Memory Processes:${_C_RESET}"
    ps aux --sort=-%mem 2>/dev/null | awk 'NR>1 && NR<=6 {printf "  %-8s %5s%%  %s\n", $1, $4, $11}'
}

healthcheck() {
    echo -e "${_C_BOLD}${_C_CYAN}=== System Health Check ===${_C_RESET}\n"

    echo -e "${_C_YELLOW}[Load Average]${_C_RESET}"
    local load cpus load_pct
    load=$(awk '{print $1}' /proc/loadavg)
    cpus=$(nproc)
    load_pct=$(awk -v l="$load" -v c="$cpus" 'BEGIN{printf "%.0f", (l/c)*100}')
    if [[ "${load_pct:-0}" -gt 100 ]]; then
        echo -e "  ${_C_RED}WARNING: Load ($load) exceeds CPU count ($cpus)${_C_RESET}"
    else
        echo -e "  ${_C_GREEN}OK: Load $load (${load_pct}% of $cpus CPUs)${_C_RESET}"
    fi

    echo -e "\n${_C_YELLOW}[Memory]${_C_RESET}"
    local mem_pct
    mem_pct=$(free | awk '/^Mem:/ {printf "%.0f", $3/$2 * 100}')
    if [[ $mem_pct -gt 90 ]]; then
        echo -e "  ${_C_RED}WARNING: Memory usage at ${mem_pct}%${_C_RESET}"
    elif [[ $mem_pct -gt 75 ]]; then
        echo -e "  ${_C_YELLOW}CAUTION: Memory usage at ${mem_pct}%${_C_RESET}"
    else
        echo -e "  ${_C_GREEN}OK: Memory usage at ${mem_pct}%${_C_RESET}"
    fi

    echo -e "\n${_C_YELLOW}[Disk Space]${_C_RESET}"
    df -h 2>/dev/null | awk 'NR>1 && /^\/dev/ {
        gsub(/%/, "", $5);
        if ($5 > 90) printf "  \033[38;5;203mCRITICAL: %s at %s%%\033[0m\n", $6, $5;
        else if ($5 > 80) printf "  \033[38;5;223mWARNING: %s at %s%%\033[0m\n", $6, $5;
        else printf "  \033[38;5;151mOK: %s at %s%%\033[0m\n", $6, $5;
    }'

    echo -e "\n${_C_YELLOW}[Failed Services]${_C_RESET}"
    local failed
    failed=$(systemctl list-units --state=failed --no-legend 2>/dev/null | awk 'NF>0' | wc -l)
    failed=${failed//[^0-9]/}
    [[ -z "$failed" ]] && failed=0
    if [[ "$failed" -gt 0 ]]; then
        echo -e "  ${_C_RED}WARNING: $failed failed service(s)${_C_RESET}"
        systemctl list-units --state=failed --no-legend 2>/dev/null | awk 'NF>0 {print "    " $1}'
    else
        echo -e "  ${_C_GREEN}OK: No failed services${_C_RESET}"
    fi

    echo -e "\n${_C_YELLOW}[SELinux]${_C_RESET}"
    local selinux=$(getenforce 2>/dev/null || echo "N/A")
    case "$selinux" in
        Enforcing)  echo -e "  ${_C_GREEN}OK: SELinux is Enforcing${_C_RESET}" ;;
        Permissive) echo -e "  ${_C_YELLOW}CAUTION: SELinux is Permissive${_C_RESET}" ;;
        *)          echo -e "  ${_C_RED}WARNING: SELinux is $selinux${_C_RESET}" ;;
    esac

    echo -e "\n${_C_YELLOW}[Zombie Processes]${_C_RESET}"
    local zombies
    zombies=$(ps aux | awk '$8 ~ /^Z/' | wc -l)
    if [[ $zombies -gt 0 ]]; then
        echo -e "  ${_C_RED}WARNING: $zombies zombie process(es)${_C_RESET}"
    else
        echo -e "  ${_C_GREEN}OK: No zombie processes${_C_RESET}"
    fi
}

svc() {
    [[ -z "$1" ]] && { echo "Usage: svc <service> [status|start|stop|restart|enable|disable|reload|log]"; return 1; }
    local service="$1" action="${2:-status}"
    case "$action" in
        status|start|stop|restart|enable|disable|reload)
            sudo systemctl "$action" "$service"
            ;;
        log)
            sudo journalctl -u "$service" -f
            ;;
        *)
            echo "Unknown action: $action"
            echo "Valid: status, start, stop, restart, enable, disable, reload, log"
            return 1
            ;;
    esac
}
