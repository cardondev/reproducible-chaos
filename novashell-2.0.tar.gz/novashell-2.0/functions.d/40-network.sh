# NovaShell functions.d/40-network — network tooling (dependency-free)

portcheck() {
    [[ -z "$1" ]] && { echo "Usage: portcheck <host> [port]"; return 1; }
    local host="$1" port="${2:-22}"
    timeout 3 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null && \
        echo -e "${_C_GREEN}Port $port on $host is OPEN${_C_RESET}" || \
        echo -e "${_C_RED}Port $port on $host is CLOSED/FILTERED${_C_RESET}"
}

portscan() {
    [[ -z "$1" ]] && { echo "Usage: portscan <host> [start_port] [end_port]"; return 1; }
    local host="$1" start="${2:-1}" end="${3:-1024}"
    echo "Scanning $host ports $start-$end..."
    for port in $(seq $start $end); do
        timeout 1 bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null && echo "Port $port: OPEN"
    done
}

whichip() {
    local iface="${1:-}"
    if [[ -n "$iface" ]]; then
        ip -4 addr show "$iface" 2>/dev/null | awk '/inet / {print $2}' | cut -d/ -f1
    else
        ip -4 addr show 2>/dev/null | awk '/inet / && !/127.0.0.1/ {print $NF ": " $2}' | cut -d/ -f1
    fi
}

certinfo() {
    [[ -z "$1" ]] && { echo "Usage: certinfo <domain>"; return 1; }
    echo | openssl s_client -servername "$1" -connect "$1:443" 2>/dev/null | openssl x509 -noout -dates -subject -issuer
}

sshtest() {
    [[ -z "$1" ]] && { echo "Usage: sshtest <host> [port]"; return 1; }
    local host="$1" port="${2:-22}"
    if timeout 5 bash -c "echo > /dev/tcp/${host}/${port}" 2>/dev/null; then
        echo -e "${_C_GREEN}${host}:${port} reachable (TCP)${_C_RESET}"
        local banner
        banner=$(timeout 3 bash -c "exec 3<>/dev/tcp/${host}/${port}; head -1 <&3" 2>/dev/null)
        [[ -n "$banner" ]] && echo "  Banner: ${banner}"
    else
        echo -e "${_C_RED}${host}:${port} not reachable${_C_RESET}"
        return 1
    fi
}

listening() {
    if [[ $EUID -eq 0 ]]; then
        ss -tulnp 2>/dev/null
    else
        ss -tuln 2>/dev/null
        echo "(run as root for process names)"
    fi
}

# http GET w/ timings — no curl-format file needed.
httping() {
    [[ -z "$1" ]] && { echo "Usage: httping <url>"; return 1; }
    curl -sS -o /dev/null -w "DNS:%{time_namelookup}s  Connect:%{time_connect}s  TLS:%{time_appconnect}s  TTFB:%{time_starttransfer}s  Total:%{time_total}s  Code:%{http_code}\n" "$1"
}
