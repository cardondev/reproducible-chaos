# NovaShell functions.d/50-process — process management

pskill() {
    [[ -z "$1" ]] && { echo "Usage: pskill <process_name>"; return 1; }
    local pids
    pids=$(pgrep -f "$1")
    if [[ -z "$pids" ]]; then
        echo "No processes found matching: $1"
        return 1
    fi
    echo "Found processes:"
    ps aux | grep -v grep | grep "$1"
    echo ""
    read -p "Kill these processes? [y/N] " -n 1 -r
    echo
    [[ $REPLY =~ ^[Yy]$ ]] && kill $pids && echo "Killed"
}

pswatch() {
    [[ -z "$1" ]] && { echo "Usage: pswatch <process_name>"; return 1; }
    watch -n 1 "ps aux | grep -v grep | grep -i $1"
}
