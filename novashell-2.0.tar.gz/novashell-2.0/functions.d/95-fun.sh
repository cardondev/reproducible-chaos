# NovaShell functions.d/95-fun — decoration

turbo_mode() {
    echo -e "${_C_YELLOW}"
    echo "TURBO MODE"
    echo -e "${_C_GREEN}"
    cat << 'EOF'
                           *     .--.
                                / /  `
               +               | |
                      '         \ \__,
                  *          +   '--'  *
                      +   /\
         +              .'  '.   *
                *      /======\      +
                      ;:.  _   ;
                      |:. (_)  |
                      |:.  _   |
            +         |:. (_)  |          *
                      ;:.      ;
                    .' \:.    / `.
                   / .-'':._.'`-. \
                   |/    /||\    \|
       NovaShell _..--"""````"""--.._
           _.-'``                    ``'-._
         -'                                '-

EOF
    echo -e "${_C_RESET}"
}
