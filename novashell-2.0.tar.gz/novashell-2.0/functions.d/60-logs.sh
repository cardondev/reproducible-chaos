# NovaShell functions.d/60-logs — log search / error surfacing

logsearch() {
    [[ -z "$1" ]] && { echo "Usage: logsearch <pattern> [logfile]"; return 1; }
    local pattern="$1" logfile="${2:-/var/log/messages}"
    sudo grep -i "$pattern" "$logfile" | tail -50
}

errorlog() {
    local lines="${1:-50}"
    echo -e "${_C_CYAN}=== Recent Errors in System Logs ===${_C_RESET}\n"
    sudo journalctl -p err -n "$lines" --no-pager 2>/dev/null || \
        sudo grep -i "error\|fail\|critical" /var/log/messages | tail -"$lines"
}

# Tail many files at once with color-coded prefixes.
multitail() {
    [[ $# -eq 0 ]] && { echo "Usage: multitail <file1> [file2 ...]"; return 1; }
    sudo tail -Fn 20 "$@"
}
