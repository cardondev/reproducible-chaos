# NovaShell functions.d/97-manage — in-shell management helpers

novashell_update() {
    echo -e "${_C_CYAN}Reloading configuration...${_C_RESET}"
    if [[ "${NOVASHELL_MODE:-native}" == "native" ]]; then
        source "$HOME/.bashrc" 2>/dev/null && \
            echo -e "${_C_GREEN}Configuration reloaded successfully${_C_RESET}" || \
            echo -e "${_C_RED}Error reloading configuration${_C_RESET}"
    else
        source "$HOME/${NOVASHELL_PREFIX}_bashrc" 2>/dev/null && \
            echo -e "${_C_GREEN}Configuration reloaded successfully${_C_RESET}" || \
            echo -e "${_C_RED}Error reloading configuration${_C_RESET}"
    fi
}

novashell_backup() {
    local backup_dir="$HOME/.novashell_backup_$(date +%Y%m%d%H%M%S)"
    mkdir -p "$backup_dir"
    if [[ "${NOVASHELL_MODE:-native}" == "native" ]]; then
        for f in ".bashrc" ".bash_profile" ".bash_aliases" ".bash_functions" ".vimrc" ".tmux.conf"; do
            [[ -f "$HOME/$f" ]] && cp "$HOME/$f" "$backup_dir/"
        done
    else
        for f in "${NOVASHELL_PREFIX}_bashrc" "${NOVASHELL_PREFIX}_aliases" "${NOVASHELL_PREFIX}_functions" "${NOVASHELL_PREFIX}_vimrc" "${NOVASHELL_PREFIX}_tmux.conf"; do
            [[ -f "$HOME/$f" ]] && cp "$HOME/$f" "$backup_dir/"
        done
    fi
    echo -e "${_C_GREEN}Backup created: $backup_dir${_C_RESET}"
}

novashell_version() {
    local v="unknown"
    [[ -f /usr/share/novashell/VERSION ]] && v=$(cat /usr/share/novashell/VERSION 2>/dev/null)
    echo "NovaShell version: $v"
    echo "Mode:              ${NOVASHELL_MODE:-native}"
    echo "Prefix:            ${NOVASHELL_PREFIX:-<none>}"
    [[ -f "$HOME/.novashell_installed" ]] && echo "Installed:         $(cat "$HOME/.novashell_installed")"
}
