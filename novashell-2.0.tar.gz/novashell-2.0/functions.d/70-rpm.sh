# NovaShell functions.d/70-rpm — rpm helpers

rpmfiles() {
    [[ -z "$1" ]] && { echo "Usage: rpmfiles <package>"; return 1; }
    rpm -ql "$1" 2>/dev/null || echo "Package '$1' not installed"
}

# Show which repo a package came from.
rpmrepo() {
    [[ -z "$1" ]] && { echo "Usage: rpmrepo <package>"; return 1; }
    if command -v dnf &>/dev/null; then
        dnf repoquery --installed --qf '%{name}-%{version}-%{release} (repo: %{reponame})\n' "$1" 2>/dev/null
    else
        yum list installed "$1" 2>/dev/null
    fi
}
