# NovaShell functions.d/65-users — user helpers

usercheck() {
    [[ -z "$1" ]] && { echo "Usage: usercheck <username>"; return 1; }
    local user="$1"
    echo -e "${_C_CYAN}User Info:${_C_RESET}"
    id "$user" 2>/dev/null || { echo "User not found"; return 1; }
    echo -e "\n${_C_CYAN}Groups:${_C_RESET}"
    groups "$user"
    echo -e "\n${_C_CYAN}Password Status:${_C_RESET}"
    sudo chage -l "$user" 2>/dev/null
    echo -e "\n${_C_CYAN}Last Login:${_C_RESET}"
    lastlog -u "$user" 2>/dev/null
    echo -e "\n${_C_CYAN}Current Sessions:${_C_RESET}"
    who | grep "^$user " || echo "No active sessions"
}
