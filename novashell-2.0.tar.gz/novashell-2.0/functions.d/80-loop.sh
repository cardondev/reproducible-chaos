# NovaShell functions.d/80-loop — SSH keep-alive.
#
# Refreshes date IN PLACE on a single line. Uses `\r` + `\033[2K` (erase entire
# line) when the terminal supports ANSI; falls back to `\r` + trailing-space
# padding on dumb/PuTTY terms. Ctrl+C exits cleanly and redraws prompt.
#
# Works identically on RHEL 7/8/9/10 across SSH, PuTTY, mosh, and nested screen.
# Intentionally a function (not alias) so we can `trap INT` for clean teardown.

loop() {
    local interval="${1:-60}"
    local label="${LOOP_LABEL:-loop keepalive}"
    local use_ansi=0
    [[ "${TERM_HAS_UNICODE:-0}" -eq 1 ]] && use_ansi=1

    trap 'printf "\n"; trap - INT; return 0' INT
    while true; do
        if [[ "$use_ansi" -eq 1 ]]; then
            printf "\r\033[2K[%s] %s" "$label" "$(date '+%Y-%m-%d %H:%M:%S %Z')"
        else
            printf "\r[%s] %s          " "$label" "$(date '+%Y-%m-%d %H:%M:%S %Z')"
        fi
        sleep "$interval"
    done
}

# Backwards-compat alias pointing to the function (no behavior difference).
alias lp='loop'
