# NovaShell functions.d/10-dirops — directory + file helpers

mkcd() { mkdir -p "$1" && cd "$1"; }

mkbak() {
    local file="$1"
    [[ -z "$file" ]] && { echo "Usage: mkbak <file>"; return 1; }
    local stamp
    stamp=$(date +%Y%m%d%H%M%S)
    cp -a "$file" "${file}.bak.${stamp}"
    echo -e "${_C_GREEN}Backup: ${file}.bak.${stamp}${_C_RESET}"
}

tmpd() {
    local dir
    dir=$(mktemp -d)
    echo "Created: $dir"
    cd "$dir"
}

# Jump N directories up. `up 3` = ../../../
up() {
    local n="${1:-1}"
    local path=""
    while (( n-- > 0 )); do path+="../"; done
    cd "$path" || return
}
