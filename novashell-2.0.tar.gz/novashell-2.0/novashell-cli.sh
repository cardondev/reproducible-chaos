#!/bin/bash
# NovaShell per-user CLI.
#
# Installed as /usr/bin/novashell by the RPM. Provides explicit, per-user opt-in
# so that a single system-wide install can coexist with users who do NOT want
# NovaShell as their shell config (shared-environment friendly).
#
# Subcommands:
#   enable    Copy bashrc/profile/vimrc/tmux.conf into $HOME; mark opted-in.
#   disable   Restore original files from backup; remove marker.
#   status    Show install / opt-in state for the current user.
#   update    Re-run enable to pick up package updates (preserves backup).
#   help      Print usage.
#
# Cleanup logic on (re)enable:
#   - Rotates old backups: keeps the 3 most recent ~/.novashell_backup_*.
#   - Removes orphaned prefix-mode files if switching to native.
#   - Never touches files that lack the NovaShell sentinel comment.

set -euo pipefail

NOVASHELL_DIR="${NOVASHELL_DIR:-/usr/share/novashell}"
MARKER="$HOME/.novashell_installed"
BACKUP_BASE="$HOME/.novashell_backup"
KEEP_BACKUPS=3
SENTINEL='# BASHRC - NovaShell'

# ---- colors -------------------------------------------------------------------
G='\e[38;5;151m' ; Y='\e[38;5;223m' ; C='\e[38;5;116m' ; R='\e[38;5;203m' ; B='\e[38;5;111m' ; N='\e[0m'

die()  { echo -e "${R}error:${N} $*" >&2; exit 1; }
info() { echo -e "${C}=>${N} $*"; }
ok()   { echo -e "${G}✓${N} $*"; }
warn() { echo -e "${Y}!${N} $*"; }

[[ -d "$NOVASHELL_DIR/aliases.d" ]] || die "NovaShell source not found at $NOVASHELL_DIR (is the package installed?)"

# ---- file map -----------------------------------------------------------------
# source-in-package → target-in-home
declare -A FILE_MAP=(
    ["bashrc"]=".bashrc"
    ["bash_profile"]=".bash_profile"
    ["vimrc"]=".vimrc"
    ["tmux.conf"]=".tmux.conf"
)

# ---- cleanup: rotate old backups ---------------------------------------------
rotate_backups() {
    local backups
    mapfile -t backups < <(ls -1dt "$HOME"/.novashell_backup_* 2>/dev/null || true)
    local total=${#backups[@]}
    (( total <= KEEP_BACKUPS )) && return 0
    local i
    for (( i=KEEP_BACKUPS; i<total; i++ )); do
        rm -rf "${backups[i]}"
        info "rotated old backup: ${backups[i]}"
    done
}

# ---- cleanup: remove orphaned prefix-mode files ------------------------------
cleanup_orphans() {
    local prefix=".novashell"
    local f
    for f in _bashrc _bash_profile _aliases _functions _vimrc _tmux.conf; do
        local target="$HOME/${prefix}${f}"
        if [[ -f "$target" ]]; then
            rm -f "$target"
            info "removed orphaned prefix file: $target"
        fi
    done
    # Legacy v1.x monolithic sourced files
    for f in .bash_aliases .bash_functions; do
        if [[ -f "$HOME/$f" ]] && head -5 "$HOME/$f" 2>/dev/null | grep -q 'ALIASES - NovaShell\|FUNCTIONS - NovaShell'; then
            rm -f "$HOME/$f"
            info "removed legacy v1 file: $HOME/$f"
        fi
    done
}

# ---- backup --------------------------------------------------------------------
do_backup() {
    local stamp backup_dir
    stamp=$(date +%Y%m%d_%H%M%S)
    backup_dir="${BACKUP_BASE}_${stamp}"

    local any=0
    for src in "${!FILE_MAP[@]}"; do
        local target="${FILE_MAP[$src]}"
        if [[ -f "$HOME/$target" ]]; then
            # Skip files we installed ourselves (check sentinel); but back up
            # first-time originals.
            if ! head -3 "$HOME/$target" 2>/dev/null | grep -q 'NovaShell'; then
                mkdir -p "$backup_dir"
                cp -a "$HOME/$target" "$backup_dir/$target"
                any=1
            fi
        fi
    done

    if [[ $any -eq 1 ]]; then
        cat > "$backup_dir/restore.sh" <<'RESTORE'
#!/bin/bash
# Restore originals captured by `novashell enable`.
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in "$SCRIPT_DIR"/.*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
    cp -a "$f" "$HOME/$fname"
    echo "restored: $fname"
done
RESTORE
        chmod +x "$backup_dir/restore.sh"
        ok "originals backed up → $backup_dir"
        echo "$backup_dir" > "$HOME/.novashell_last_backup"
    fi
}

# ---- install --------------------------------------------------------------------
do_install() {
    info "installing NovaShell for $(whoami) from $NOVASHELL_DIR"

    do_backup
    cleanup_orphans

    export NOVASHELL_ROOT="$NOVASHELL_DIR"
    export NOVASHELL_MODE="native"

    for src in "${!FILE_MAP[@]}"; do
        local target="${FILE_MAP[$src]}"
        local src_file="$NOVASHELL_DIR/$src"
        [[ -f "$src_file" ]] || continue
        cp "$src_file" "$HOME/$target"
        chmod 644 "$HOME/$target"
        ok "installed ~/$target"
    done

    # Make sure bash_profile sources bashrc.
    if ! grep -q 'source.*\.bashrc' "$HOME/.bash_profile" 2>/dev/null; then
        cat >> "$HOME/.bash_profile" <<'PROFILE'

# Source .bashrc for login shells
if [[ -f "$HOME/.bashrc" ]]; then
    source "$HOME/.bashrc"
fi
PROFILE
    fi

    mkdir -p "$HOME/.vim/undodir"

    # Deploy neovim config only when nvim is installed.
    if command -v nvim &>/dev/null && [[ -f "$NOVASHELL_DIR/init.lua" ]]; then
        mkdir -p "$HOME/.config/nvim" "$HOME/.local/share/nvim/undo"
        if [[ -f "$HOME/.config/nvim/init.lua" ]] && ! head -5 "$HOME/.config/nvim/init.lua" 2>/dev/null | grep -q 'INIT.LUA - NovaShell'; then
            local nvbak="$HOME/.config/nvim/init.lua.pre-novashell.$(date +%Y%m%d%H%M%S)"
            cp -a "$HOME/.config/nvim/init.lua" "$nvbak"
            info "backed up existing nvim config → $nvbak"
        fi
        cp "$NOVASHELL_DIR/init.lua" "$HOME/.config/nvim/init.lua"
        chmod 644 "$HOME/.config/nvim/init.lua"
        ok "installed ~/.config/nvim/init.lua"
    fi

    rotate_backups

    # Marker: ISO timestamp + version.
    local version="unknown"
    [[ -f "$NOVASHELL_DIR/VERSION" ]] && version=$(cat "$NOVASHELL_DIR/VERSION")
    printf 'version=%s\ninstalled=%s\nroot=%s\n' "$version" "$(date -Iseconds)" "$NOVASHELL_DIR" > "$MARKER"

    echo ""
    ok "NovaShell enabled for $(whoami). Run 'source ~/.bashrc' or start a new shell."
    echo ""
    echo -e "  ${B}novashell status${N}   — show state"
    echo -e "  ${B}novashell disable${N}  — restore originals"
    echo -e "  ${B}helpme${N}             — in-shell cheat sheet"
}

# ---- disable / restore ---------------------------------------------------------
do_disable() {
    info "disabling NovaShell for $(whoami)"

    # Prefer the most recent captured backup; fall back to newest matching dir.
    local last_backup=""
    if [[ -f "$HOME/.novashell_last_backup" ]]; then
        last_backup=$(cat "$HOME/.novashell_last_backup" 2>/dev/null || true)
    fi
    if [[ -z "$last_backup" ]] || [[ ! -d "$last_backup" ]]; then
        last_backup=$(ls -1dt "$HOME"/.novashell_backup_* 2>/dev/null | head -1 || true)
    fi

    if [[ -n "$last_backup" ]] && [[ -d "$last_backup" ]]; then
        info "restoring from $last_backup"
        for f in "$last_backup"/.*; do
            [[ -f "$f" ]] || continue
            local fname=$(basename "$f")
            [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
            cp -a "$f" "$HOME/$fname"
            ok "restored $fname"
        done
    else
        warn "no backup directory found — removing installed files only"
        for src in "${!FILE_MAP[@]}"; do
            local target="${FILE_MAP[$src]}"
            if [[ -f "$HOME/$target" ]] && head -3 "$HOME/$target" 2>/dev/null | grep -q 'NovaShell'; then
                rm -f "$HOME/$target"
                ok "removed ~/$target"
            fi
        done
    fi

    rm -f "$MARKER" "$HOME/.novashell_last_backup"
    ok "NovaShell disabled. Start a new shell to take effect."
}

# ---- status -------------------------------------------------------------------
do_status() {
    echo -e "${C}NovaShell status for $(whoami)${N}"
    echo "  Package root:   $NOVASHELL_DIR"
    local version="unknown"
    [[ -f "$NOVASHELL_DIR/VERSION" ]] && version=$(cat "$NOVASHELL_DIR/VERSION")
    echo "  Package version: $version"

    if [[ -f "$MARKER" ]]; then
        echo -e "  Opt-in state:    ${G}enabled${N}"
        sed 's/^/    /' "$MARKER"
    else
        echo -e "  Opt-in state:    ${Y}disabled${N} (run 'novashell enable' to opt in)"
    fi

    local backups
    mapfile -t backups < <(ls -1dt "$HOME"/.novashell_backup_* 2>/dev/null || true)
    echo "  Backups retained: ${#backups[@]}"
    local b
    for b in "${backups[@]:0:3}"; do echo "    $b"; done
}

# ---- update -------------------------------------------------------------------
do_update() {
    if [[ ! -f "$MARKER" ]]; then
        die "not currently enabled — nothing to update. Run 'novashell enable' first."
    fi
    info "re-applying latest files from $NOVASHELL_DIR"
    do_install
}

# ---- help ---------------------------------------------------------------------
show_help() {
    cat <<EOF
NovaShell CLI — per-user opt-in management

Usage: novashell <command>

Commands:
  enable    Install NovaShell config for the current user (with backup).
  disable   Restore original config files; remove opt-in marker.
  status    Show current install + opt-in state for the user.
  update    Re-apply package files (use after 'dnf update novashell').
  help      Show this help.

Layout:
  $NOVASHELL_DIR/           ← system-wide package (read-only)
  ~/.bashrc, ~/.vimrc, …    ← copied here on 'enable'
  ~/.novashell_installed    ← opt-in marker
  ~/.novashell_backup_*/    ← rotated originals (keeps $KEEP_BACKUPS most recent)

Environment variables:
  NOVASHELL_DIR       Override package location.
  NOVASHELL_PROMPT    Select prompt: fancy (default) / minimal / pico / nova / dev.
  NOVASHELL_NO_WELCOME=1  Skip welcome screen.
EOF
}

case "${1:-help}" in
    enable)  do_install ;;
    disable|restore) do_disable ;;
    status)  do_status ;;
    update|reinstall) do_update ;;
    help|--help|-h) show_help ;;
    *) die "unknown command: $1 (try 'novashell help')" ;;
esac
