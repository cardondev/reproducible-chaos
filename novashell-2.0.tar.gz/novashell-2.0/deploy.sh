#!/bin/bash
# DEPLOY - NovaShell v2.0
#
# Tarball/source installer. Copies the whole tree into $HOME/.novashell/ and
# installs bashrc/bash_profile/vimrc/tmux.conf for the invoking user.
# For RPM-based installs use `dnf install novashell-*.rpm` + `novashell enable`.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOME_NS="$HOME/.novashell"
BACKUP_BASE="$HOME/.novashell_backup"
MARKER="$HOME/.novashell_installed"
KEEP_BACKUPS=3

G='\e[38;5;151m' ; Y='\e[38;5;223m' ; C='\e[38;5;116m' ; R='\e[38;5;203m' ; B='\e[38;5;111m' ; N='\e[0m' ; BOLD='\e[1m'

info()    { echo -e "${C}=>${N} $*"; }
ok()      { echo -e "${G}✓${N} $*"; }
warn()    { echo -e "${Y}!${N} $*"; }
err()     { echo -e "${R}error:${N} $*" >&2; }
section() { echo -e "\n${BOLD}${C}=== $1 ===${N}\n"; }

confirm() {
    local prompt="${1:-Continue?}"
    read -p "$(echo -e "${Y}$prompt [y/N]:${N} ")" -n 1 -r
    echo
    [[ $REPLY =~ ^[Yy]$ ]]
}

show_banner() {
    echo -e "${BOLD}${C}"
    cat <<'BANNER'
    _   __                 _____ __         ____
   / | / /___ _   ______  / ___// /_  ___  / / /
  /  |/ / __ \ | / / __ \\\__ \/ __ \/ _ \/ / /
 / /|  / /_/ / |/ / /_/ /__/ / / / /  __/ / /
/_/ |_/\____/|___/\__,_/____/_/ /_/\___/_/_/

    v2.0 — opt-in per user
BANNER
    echo -e "${N}"
}

detect_system() {
    section "System Detection"
    if [[ -f /etc/redhat-release ]]; then
        info "OS: $(cat /etc/redhat-release)"
    elif [[ -f /etc/os-release ]]; then
        info "OS: $(grep PRETTY_NAME /etc/os-release | cut -d'"' -f2)"
    else
        warn "Unknown OS"
    fi
    info "User: $(whoami)  Home: $HOME  Bash: ${BASH_VERSION}"
}

install_deps() {
    section "Optional Dependencies"

    if ! command -v dnf &>/dev/null && ! command -v yum &>/dev/null; then
        warn "no package manager found — skipping"
        return 0
    fi

    local pkg_mgr="dnf"
    command -v dnf &>/dev/null || pkg_mgr="yum"

    local rhel_ver=9
    if [[ -f /etc/redhat-release ]]; then
        rhel_ver=$(grep -oE 'release[[:space:]]+[0-9]+' /etc/redhat-release 2>/dev/null | grep -oE '[0-9]+' | head -1)
    elif [[ -f /etc/os-release ]]; then
        rhel_ver=$(. /etc/os-release; echo "${VERSION_ID%%.*}")
    fi
    [[ -z "$rhel_ver" ]] || ! [[ "$rhel_ver" =~ ^[0-9]+$ ]] && rhel_ver=9
    info "Detected RHEL major: ${rhel_ver}"

    # Per spec rules: RHEL 7 = native only unless EPEL. RHEL 8+ = AppStream + EPEL.
    local base_pkgs=() epel_pkgs=()
    case "$rhel_ver" in
        7)
            base_pkgs=()
            epel_pkgs=(tmux fzf htop)
            ;;
        8)
            base_pkgs=(tmux)
            epel_pkgs=(fzf bat fd-find ripgrep htop)
            ;;
        9|10)
            base_pkgs=(tmux)
            epel_pkgs=(fzf bat fd-find ripgrep htop neovim)
            ;;
        *)
            warn "unknown RHEL ${rhel_ver} — assuming 9+"
            base_pkgs=(tmux)
            epel_pkgs=(fzf bat fd-find ripgrep htop neovim)
            ;;
    esac

    local has_epel=0
    if rpm -q epel-release &>/dev/null; then
        if "$pkg_mgr" repolist --enabled 2>/dev/null | awk 'NR>1 {print $1}' | grep -qi '^epel'; then
            has_epel=1
        fi
    fi

    local available_pkgs=()
    if [[ "$has_epel" -eq 1 ]]; then
        info "EPEL enabled — base + EPEL packages available"
        available_pkgs=("${base_pkgs[@]}" "${epel_pkgs[@]}")
    else
        warn "EPEL not detected — only base-repo packages available"
        [[ ${#epel_pkgs[@]} -gt 0 ]] && warn "Skipping: ${epel_pkgs[*]}"
        available_pkgs=("${base_pkgs[@]}")
    fi

    [[ ${#available_pkgs[@]} -eq 0 ]] && { info "nothing to install"; return 0; }

    local to_install=()
    for pkg in "${available_pkgs[@]}"; do
        rpm -q "$pkg" &>/dev/null || to_install+=("$pkg")
    done
    [[ ${#to_install[@]} -eq 0 ]] && { ok "all optional packages already installed"; return 0; }

    echo "Available optional packages:"
    printf "  %s\n" "${to_install[@]}"
    echo ""

    if confirm "Install optional packages? (needs sudo)"; then
        for pkg in "${to_install[@]}"; do
            info "installing $pkg"
            sudo "$pkg_mgr" install -y "$pkg" &>/dev/null && ok "installed $pkg" || warn "failed to install $pkg"
        done
    else
        info "skipping"
    fi
}

rotate_backups() {
    local backups
    mapfile -t backups < <(ls -1dt "$HOME"/.novashell_backup_* 2>/dev/null || true)
    local total=${#backups[@]}
    (( total <= KEEP_BACKUPS )) && return 0
    local i
    for (( i=KEEP_BACKUPS; i<total; i++ )); do
        rm -rf "${backups[i]}"
        info "rotated old backup: ${backups[i]}"
    done
}

cleanup_orphans() {
    local f
    for f in _bashrc _bash_profile _aliases _functions _vimrc _tmux.conf; do
        [[ -f "$HOME/.novashell${f}" ]] && rm -f "$HOME/.novashell${f}" && info "removed orphaned prefix file: ~/.novashell${f}"
    done
    for f in .bash_aliases .bash_functions; do
        if [[ -f "$HOME/$f" ]] && head -5 "$HOME/$f" 2>/dev/null | grep -q 'NovaShell'; then
            rm -f "$HOME/$f"
            info "removed legacy v1 file: ~/$f"
        fi
    done
}

backup_originals() {
    section "Backup"
    local stamp backup_dir any=0
    stamp=$(date +%Y%m%d_%H%M%S)
    backup_dir="${BACKUP_BASE}_${stamp}"

    for target in .bashrc .bash_profile .vimrc .tmux.conf; do
        if [[ -f "$HOME/$target" ]] && ! head -3 "$HOME/$target" 2>/dev/null | grep -q 'NovaShell'; then
            mkdir -p "$backup_dir"
            cp -a "$HOME/$target" "$backup_dir/$target"
            any=1
        fi
    done

    if [[ $any -eq 1 ]]; then
        cat > "$backup_dir/restore.sh" <<'RESTORE'
#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in "$SCRIPT_DIR"/.*; do
    [[ -f "$f" ]] || continue
    fname=$(basename "$f")
    [[ "$fname" == "." ]] || [[ "$fname" == ".." ]] || [[ "$fname" == "restore.sh" ]] && continue
    cp -a "$f" "$HOME/$fname"
    echo "restored: $fname"
done
RESTORE
        chmod +x "$backup_dir/restore.sh"
        ok "originals saved → $backup_dir"
        echo "$backup_dir" > "$HOME/.novashell_last_backup"
    else
        info "no originals to back up"
    fi
}

install_files() {
    section "Installing NovaShell Tree"

    mkdir -p "$HOME_NS/aliases.d" "$HOME_NS/functions.d" "$HOME_NS/prompts"

    cp -a "$SCRIPT_DIR"/aliases.d/.   "$HOME_NS/aliases.d/"
    cp -a "$SCRIPT_DIR"/functions.d/. "$HOME_NS/functions.d/"
    cp -a "$SCRIPT_DIR"/prompts/.     "$HOME_NS/prompts/"

    # Top-level config files
    cp "$SCRIPT_DIR/bashrc"       "$HOME/.bashrc"
    cp "$SCRIPT_DIR/bash_profile" "$HOME/.bash_profile"
    cp "$SCRIPT_DIR/vimrc"        "$HOME/.vimrc"
    cp "$SCRIPT_DIR/tmux.conf"    "$HOME/.tmux.conf"
    chmod 644 "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.vimrc" "$HOME/.tmux.conf"

    # Ensure bash_profile sources bashrc
    if ! grep -q 'source.*\.bashrc' "$HOME/.bash_profile" 2>/dev/null; then
        cat >> "$HOME/.bash_profile" <<'PROFILE'

# Source .bashrc for login shells
if [[ -f "$HOME/.bashrc" ]]; then
    source "$HOME/.bashrc"
fi
PROFILE
    fi

    mkdir -p "$HOME/.vim/undodir"

    # Deploy neovim config if nvim is present (RHEL 9/10)
    if command -v nvim &>/dev/null && [[ -f "$SCRIPT_DIR/init.lua" ]]; then
        mkdir -p "$HOME/.config/nvim" "$HOME/.local/share/nvim/undo"
        if [[ -f "$HOME/.config/nvim/init.lua" ]] && ! head -5 "$HOME/.config/nvim/init.lua" | grep -q 'NovaShell'; then
            cp -a "$HOME/.config/nvim/init.lua" "$HOME/.config/nvim/init.lua.pre-novashell.$(date +%Y%m%d%H%M%S)"
        fi
        cp "$SCRIPT_DIR/init.lua" "$HOME/.config/nvim/init.lua"
        chmod 644 "$HOME/.config/nvim/init.lua"
        ok "installed ~/.config/nvim/init.lua"
    fi

    # Write NOVASHELL_ROOT env into bashrc precedence: it'll auto-detect from HOME_NS.
    local version="2.0"
    [[ -f "$SCRIPT_DIR/VERSION" ]] && version=$(cat "$SCRIPT_DIR/VERSION")
    printf 'version=%s\ninstalled=%s\nroot=%s\n' "$version" "$(date -Iseconds)" "$HOME_NS" > "$MARKER"

    ok "config root: $HOME_NS"
    ok "marker:      $MARKER"
}

print_summary() {
    section "Done"
    echo -e "${G}NovaShell v$(cat "$SCRIPT_DIR/VERSION" 2>/dev/null || echo 2.0) installed for $(whoami).${N}"
    echo ""
    echo -e "Run ${C}source ~/.bashrc${N} or start a new shell."
    echo ""
    echo -e "Switch prompts: ${C}fancypants / lowkey / pico / nova / dev${N}"
    echo -e "Cheat sheet:    ${C}helpme${N}"
}

do_install() {
    show_banner
    detect_system
    install_deps
    backup_originals
    cleanup_orphans
    install_files
    rotate_backups
    print_summary
}

do_restore() {
    section "Restore"
    local last="$(cat "$HOME/.novashell_last_backup" 2>/dev/null || true)"
    if [[ -z "$last" ]] || [[ ! -d "$last" ]]; then
        last=$(ls -1dt "$HOME"/.novashell_backup_* 2>/dev/null | head -1 || true)
    fi
    [[ -z "$last" ]] && { err "no backup found"; return 1; }
    info "restoring from $last"
    bash "$last/restore.sh"
    rm -f "$MARKER" "$HOME/.novashell_last_backup"
    ok "restored. Start a new shell."
}

do_uninstall() {
    section "Uninstall"
    if confirm "Remove NovaShell config from $HOME?"; then
        rm -rf "$HOME_NS"
        cleanup_orphans
        do_restore || true
        ok "uninstalled."
    fi
}

show_help() {
    cat <<EOF
NovaShell Deploy Script v2.0

Usage: $0 [install|restore|uninstall|help]

Commands:
  install     Install NovaShell config for the current user (default).
  restore     Restore original config from the latest backup.
  uninstall   Remove NovaShell files and restore originals.

For RPM-managed deployment: sudo dnf install novashell-*.rpm && novashell enable
EOF
}

main() {
    case "${1:-install}" in
        install)   do_install ;;
        restore)   do_restore ;;
        uninstall) do_uninstall ;;
        help|-h|--help) show_help ;;
        *) err "unknown command: $1"; show_help; exit 1 ;;
    esac
}

main "$@"
