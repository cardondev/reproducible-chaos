# NovaShell prompts/50-dev — "engineer's daily driver" (my choice).
# Name: prompt_dev / alias dev
#
# One line, built for dev work:
#   [rc] user@host cwd {venv k8s tmux} ∎
#
# - Exit code badge only on failure; otherwise silent.
# - Shows venv (python), current kube context, tmux session when inside one.
# - SSH-aware: subtle orange marker when on a remote host.
# - No sleeps, no animations — cheap PROMPT_COMMAND.

_ns_build_dev() {
    local rc=$?
    local cwd
    cwd=$(_ns_short_cwd)

    local user_col="${P_USER}" glyph_col="${P_GREEN}" glyph="∎"
    [[ $EUID -eq 0 ]] && { user_col="${P_ROOT}"; glyph_col="${P_ROOT}"; glyph="#"; }

    # Build context cluster
    local ctx=""
    local v k t s
    v=$(_ns_venv); [[ -n "$v" ]] && ctx+="${P_MAUVE}${v} "
    k=$(_ns_k8s);  [[ -n "$k" ]] && ctx+="${P_PINK}${k} "
    t=$(_ns_tmux); [[ -n "$t" ]] && ctx+="${P_TIME}${t} "
    s=$(_ns_ssh);  [[ -n "$s" ]] && ctx+="${P_PEACH}${s} "
    [[ -n "$ctx" ]] && ctx="${P_OVERLAY}{${P_RESET}${ctx%% }${P_OVERLAY}} "

    local rc_badge=""
    [[ $rc -ne 0 ]] && rc_badge="${P_RED}[${rc}]${P_RESET} "

    PS1="${rc_badge}${user_col}\u${P_OVERLAY}@${P_HOST}\h ${P_PATH}${cwd} ${ctx}${glyph_col}${glyph}${P_RESET} "
}

prompt_dev() {
    export NOVASHELL_PROMPT=dev
    PROMPT_COMMAND='_ns_build_dev'
}
