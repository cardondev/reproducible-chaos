# NovaShell prompts/20-minimal — original "lowkey" minimal prompt.
# Name: prompt_minimal / alias lowkey

prompt_minimal() {
    export NOVASHELL_PROMPT=minimal
    unset PROMPT_COMMAND
    PS1="${P_HOST}\h${P_YELLOW} ${P_PEACH}>${P_RESET} "
}
