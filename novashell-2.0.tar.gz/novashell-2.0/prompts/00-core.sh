# NovaShell prompts/00-core — shared prompt helpers
#
# Color palette (Catppuccin Mocha) as raw ANSI for PS1 (with \[\] wrappers)
# and printf (without wrappers). Defined centrally so all prompts share them.

# ---- PS1-safe colors (wrapped) -------------------------------------------------
P_RESET='\[\e[0m\]'
P_BOLD='\[\e[1m\]'
P_ITALIC='\[\e[3m\]'
P_BLINK='\[\e[5m\]'
P_YELLOW='\[\e[38;2;249;226;175m\]'
P_TIME='\[\e[38;2;137;220;235m\]'
P_DATE='\[\e[38;2;250;179;135m\]'
P_USER='\[\e[38;2;166;209;137m\]'
P_HOST='\[\e[38;2;148;226;213m\]'
P_PATH='\[\e[38;2;184;233;148m\]'
P_TEXT='\[\e[38;2;205;214;244m\]'
P_ROOT='\[\e[38;2;243;139;168m\]'
P_MAUVE='\[\e[38;2;203;166;247m\]'
P_PINK='\[\e[38;2;245;194;231m\]'
P_OVERLAY='\[\e[38;2;108;112;134m\]'
P_PEACH='\[\e[38;2;250;179;135m\]'
P_GREEN='\[\e[38;2;166;227;161m\]'
P_RED='\[\e[38;2;243;139;168m\]'

# ---- Raw ANSI (no wrappers) — for printf/echo ---------------------------------
_R_RESET='\e[0m'
_R_YELLOW='\e[38;2;249;226;175m'
_R_TIME='\e[38;2;137;220;235m'
_R_DATE='\e[38;2;250;179;135m'
_R_USER='\e[38;2;166;209;137m'
_R_HOST='\e[38;2;148;226;213m'
_R_PATH='\e[38;2;184;233;148m'
_R_TEXT='\e[38;2;205;214;244m'
_R_ROOT='\e[38;2;243;139;168m'
_R_MAUVE='\e[38;2;203;166;247m'
_R_PINK='\e[38;2;245;194;231m'
_R_OVERLAY='\e[38;2;108;112;134m'
_R_PEACH='\e[38;2;250;179;135m'
_R_GREEN='\e[38;2;166;227;161m'
_R_RED='\e[38;2;243;139;168m'
_R_ITALIC='\e[3m'
_R_BLINK='\e[5m'

# ---- Shared utilities ----------------------------------------------------------

# Short cwd: ~ for $HOME, last 3 segments when deep.
_ns_short_cwd() {
    local cwd="${PWD/#$HOME/~}"
    local IFS=/
    local -a parts=($cwd)
    local n=${#parts[@]}
    if (( n > 4 )); then
        echo ".../${parts[n-3]}/${parts[n-2]}/${parts[n-1]}"
    else
        echo "$cwd"
    fi
}

# Context fragments — printed by prompts that opt in.
_ns_venv()   { [[ -n "$VIRTUAL_ENV" ]] && echo "(${VIRTUAL_ENV##*/})"; }
_ns_k8s()    {
    command -v kubectl &>/dev/null || return
    local ctx
    ctx=$(kubectl config current-context 2>/dev/null) || return
    echo "k8s:${ctx}"
}
_ns_tmux()   { [[ -n "$TMUX" ]] && echo "tmux:$(tmux display -p '#S' 2>/dev/null)"; }
_ns_ssh()    { [[ -n "$SSH_CONNECTION" ]] && echo "ssh"; }
_ns_jobs()   {
    local j
    j=$(jobs -p 2>/dev/null | wc -l)
    j=${j//[^0-9]/}
    [[ "${j:-0}" -gt 0 ]] && echo "jobs:$j"
}
