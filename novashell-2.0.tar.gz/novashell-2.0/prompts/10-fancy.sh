# NovaShell prompts/10-fancy — original three-line prompt with animated arrows.
# Name: prompt_fancy / alias fancypants

_ns_cmd_separator() {
    local cols="${COLUMNS:-$(tput cols 2>/dev/null || echo 80)}"
    local sep="" pattern="${P_SEP}"
    local pattern_len=${#pattern}
    local i=0
    while [[ $i -lt $cols ]]; do
        sep+="${pattern}"
        ((i+=pattern_len))
    done
    sep="${sep:0:$cols}"
    echo -e "\e[38;2;249;226;175m${sep}\e[0m"
}

_ns_build_fancy() {
    local time_str date_str cwd
    time_str=$(date '+%H:%M:%S %Z')
    date_str=$(date '+%A, %B %d, %Y')
    cwd="${PWD/#$HOME/~}"

    local r_user_color="${_R_USER}" ps1_user_color="${P_USER}"
    local prompt_char="${P_ARROW}" r_prompt_color="${_R_TEXT}" ps1_prompt_color="${P_TEXT}"
    if [[ $EUID -eq 0 ]]; then
        r_user_color="${_R_ROOT}"; ps1_user_color="${P_ROOT}"
        prompt_char="${P_BOLT}${P_ARROW}"
        r_prompt_color="${_R_ROOT}${_R_BLINK}"; ps1_prompt_color="${P_ROOT}${P_BLINK}"
    fi

    printf "${_R_YELLOW}${P_TL}${P_H}[${_R_TIME}${time_str}${_R_YELLOW}]"
    printf "${_R_YELLOW}${P_H}[${_R_DATE}${date_str}${_R_YELLOW}]"
    printf "${_R_YELLOW}${P_H}[${r_user_color}${USER}${_R_TEXT}@${_R_HOST}${HOSTNAME}${_R_YELLOW}]"
    printf "${_R_RESET}\n"

    printf "${_R_YELLOW}${P_ML}${P_H}[${_R_PATH}${cwd}${_R_YELLOW}]${_R_RESET}\n"

    printf "${_R_YELLOW}${P_BL}${P_H}${_R_RESET}"
    if [[ "${TERM_HAS_UNICODE:-0}" -eq 1 ]]; then
        printf "${_R_ITALIC}${r_prompt_color}❯${_R_RESET}"; sleep 0.06
        printf "${_R_ITALIC}${r_prompt_color}❯${_R_RESET}"; sleep 0.06
        printf "${_R_ITALIC}${r_prompt_color}❯${_R_RESET}"; sleep 0.06
    else
        printf "${r_prompt_color}>${_R_RESET}"; sleep 0.06
        printf "${r_prompt_color}>${_R_RESET}"; sleep 0.06
        printf "${r_prompt_color}>${_R_RESET}"; sleep 0.06
    fi
    printf " \r"
    printf "\e[1 q"

    PS1="${P_YELLOW}${P_BL}${P_H}${P_RESET}${ps1_prompt_color}${P_ITALIC}${prompt_char}${P_RESET} "
}

prompt_fancy() {
    export NOVASHELL_PROMPT=fancy
    PROMPT_COMMAND='_ns_cmd_separator; _ns_build_fancy'
}
