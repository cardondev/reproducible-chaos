# NovaShell prompts/40-nova — "full-fledged awesome".
# Name: prompt_nova / alias nova
#
# Two lines:
#   ╭─[user@host]─[cwd]────────────────[venv k8s ssh jobs tmux retcode time]
#   ╰─❯
#
# Right-aligned context segments. Powerline-style rounded corners when TERM
# supports Unicode; ASCII fallback on PuTTY. No git (perf per v1.3).

_ns_nova_rsegments() {
    local rc="$1"
    local out=""
    local v k j t s
    v=$(_ns_venv);   [[ -n "$v" ]] && out+=" ${_R_MAUVE}${v}${_R_RESET}"
    k=$(_ns_k8s);    [[ -n "$k" ]] && out+=" ${_R_PINK}${k}${_R_RESET}"
    s=$(_ns_ssh);    [[ -n "$s" ]] && out+=" ${_R_PEACH}${s}${_R_RESET}"
    j=$(_ns_jobs);   [[ -n "$j" ]] && out+=" ${_R_YELLOW}${j}${_R_RESET}"
    t=$(_ns_tmux);   [[ -n "$t" ]] && out+=" ${_R_TIME}${t}${_R_RESET}"
    if [[ $rc -ne 0 ]]; then
        out+=" ${_R_RED}✗${rc}${_R_RESET}"
    else
        out+=" ${_R_GREEN}✓${_R_RESET}"
    fi
    out+=" ${_R_TIME}$(date '+%H:%M:%S')${_R_RESET}"
    printf '%b' "$out"
}

# Strip ANSI for length calculation.
_ns_strip_ansi() {
    printf '%s' "$1" | sed 's/\x1B\[[0-9;]*[a-zA-Z]//g'
}

_ns_build_nova() {
    local rc=$?
    local unicode=$TERM_HAS_UNICODE
    local tl ml bl h arrow
    if [[ "$unicode" -eq 1 ]]; then
        tl="╭" ; ml="├" ; bl="╰" ; h="─" ; arrow="❯"
    else
        tl="+" ; ml="|" ; bl="+" ; h="-" ; arrow=">"
    fi

    local user_col="${_R_USER}" arrow_col="${_R_PEACH}"
    [[ $EUID -eq 0 ]] && { user_col="${_R_ROOT}"; arrow_col="${_R_RED}"; }

    local cwd="${PWD/#$HOME/~}"
    local left_str="${tl}${h}[${USER}@${HOSTNAME}]${h}[${cwd}]"
    local left_fmt="${_R_YELLOW}${tl}${h}[${user_col}${USER}${_R_RESET}${_R_TEXT}@${_R_HOST}${HOSTNAME}${_R_YELLOW}]${h}[${_R_PATH}${cwd}${_R_YELLOW}]${_R_RESET}"

    local right_fmt
    right_fmt=$(_ns_nova_rsegments $rc)
    local right_plain
    right_plain=$(_ns_strip_ansi "$right_fmt")
    local left_plain
    left_plain=$(_ns_strip_ansi "$left_str")

    local cols="${COLUMNS:-$(tput cols 2>/dev/null || echo 80)}"
    local gap=$(( cols - ${#left_plain} - ${#right_plain} - 1 ))
    (( gap < 1 )) && gap=1
    local fill
    printf -v fill '%*s' "$gap" ''
    fill="${fill// /$h}"

    printf "%b" "$left_fmt"
    printf "${_R_YELLOW}%s${_R_RESET}" "$fill"
    printf "%b\n" "$right_fmt"

    PS1="${P_YELLOW}${bl}${h}${P_RESET}${arrow_col:+\[\e[38;2;250;179;135m\]}${arrow}${P_RESET} "
    # Rewrite arrow color dynamically
    if [[ $EUID -eq 0 ]]; then
        PS1="${P_YELLOW}${bl}${h}${P_ROOT}${arrow}${P_RESET} "
    else
        PS1="${P_YELLOW}${bl}${h}${P_PEACH}${arrow}${P_RESET} "
    fi
}

prompt_nova() {
    export NOVASHELL_PROMPT=nova
    PROMPT_COMMAND='_ns_build_nova'
}
