# NovaShell prompts/99-aliases — short aliases for prompt switching

alias fancypants='prompt_fancy'
alias lowkey='prompt_minimal'
alias pico='prompt_pico'
alias nova='prompt_nova'
alias dev='prompt_dev'

# Show currently active prompt name
promptname() { echo "${NOVASHELL_PROMPT:-unset}"; }
