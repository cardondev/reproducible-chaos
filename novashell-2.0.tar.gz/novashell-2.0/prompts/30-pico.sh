# NovaShell prompts/30-pico — "minimal with enough info".
# Name: prompt_pico / alias pico
#
# One line: user@host path exit-code-badge λ/#
#  - Green λ on success, red # on non-zero exit.
#  - Short cwd (last 3 segments when deep).
#  - Root: red username, # glyph.
#  - No animations, no PROMPT_COMMAND sleeps — feels instant.

_ns_pico_exit() {
    local rc=$?
    if [[ $rc -eq 0 ]]; then
        printf '%b' "${_R_GREEN}✓${_R_RESET}"
    else
        printf '%b' "${_R_RED}✗${rc}${_R_RESET}"
    fi
}

_ns_build_pico() {
    local rc=$?
    local cwd
    cwd=$(_ns_short_cwd)

    local user_col="${P_USER}" glyph="λ" glyph_col="${P_GREEN}"
    [[ $EUID -eq 0 ]] && { user_col="${P_ROOT}"; glyph="#"; glyph_col="${P_ROOT}"; }
    [[ $rc -ne 0 ]] && glyph_col="${P_RED}"

    # Exit badge (only when nonzero to keep it clean)
    local badge=""
    if [[ $rc -ne 0 ]]; then
        badge="${P_RED}[${rc}]${P_RESET} "
    fi

    PS1="${user_col}\u${P_OVERLAY}@${P_HOST}\h ${P_PATH}${cwd}${P_RESET} ${badge}${glyph_col}${glyph}${P_RESET} "
}

prompt_pico() {
    export NOVASHELL_PROMPT=pico
    PROMPT_COMMAND='_ns_build_pico'
}
