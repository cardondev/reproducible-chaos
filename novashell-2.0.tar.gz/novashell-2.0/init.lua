-- =============================================================================
-- INIT.LUA - NovaShell Neovim Configuration v2.0
-- Theme: Catppuccin Mocha (hardcoded — no plugins, no network, no git)
--
-- Optional component: only deployed when `nvim` is present. Intended for
-- RHEL 9/10 & Rocky 9/10 where nvim ships in AppStream or EPEL. Older RHEL
-- versions fall back to the vim config.
--
-- Compat: Neovim 0.5+. Every feature below is feature-detected at runtime.
-- All external-tool integration (fzf, rg, LSP) is guarded behind
-- `vim.fn.executable` checks — no external requests, no plugin manager.
-- =============================================================================

-- Feature detection. vim.version() was added in 0.8; fall back to has() for
-- older builds so a truly ancient nvim still sources this file without error.
local nvim_version = (function()
    if vim.version and type(vim.version) == "function" then
        local v = vim.version()
        return (v.major or 0) * 10000 + (v.minor or 0) * 100 + (v.patch or 0)
    end
    -- Very old: approximate from has('nvim-0.x.y')
    for _, probe in ipairs({ "0.9.0", "0.8.0", "0.7.0", "0.6.0", "0.5.0" }) do
        if vim.fn.has("nvim-" .. probe) == 1 then
            local maj, min, pat = probe:match("(%d+)%.(%d+)%.(%d+)")
            return tonumber(maj) * 10000 + tonumber(min) * 100 + tonumber(pat)
        end
    end
    return 0
end)()

local function nvim_at_least(maj, min, pat)
    return nvim_version >= (maj * 10000 + min * 100 + (pat or 0))
end

-- Leader
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- -----------------------------------------------------------------------------
-- General
-- -----------------------------------------------------------------------------
local opt = vim.opt
opt.encoding       = "utf-8"
opt.fileencoding   = "utf-8"
opt.ttyfast        = true
opt.lazyredraw     = true
opt.updatetime     = 250
opt.timeoutlen     = 500
opt.history        = 1000
opt.undolevels     = 1000
opt.backspace      = { "indent", "eol", "start" }
opt.hidden         = true
opt.mouse          = "a"
opt.clipboard      = "unnamedplus"
opt.confirm        = true
opt.shortmess:append("c")
opt.shortmess:append("I")  -- no intro

-- -----------------------------------------------------------------------------
-- Display
-- -----------------------------------------------------------------------------
opt.number         = true
opt.relativenumber = true
opt.ruler          = true
opt.cursorline     = true
opt.showmatch      = true
opt.matchtime      = 2
opt.wrap           = false
opt.linebreak      = true
opt.scrolloff      = 8
opt.sidescrolloff  = 8
opt.signcolumn     = "yes"
opt.colorcolumn    = "100"
opt.termguicolors  = true
opt.showmode       = false
opt.laststatus     = 2
opt.cmdheight      = 1
opt.pumheight      = 12
opt.splitright     = true
opt.splitbelow     = true
opt.fillchars      = { eob = " ", vert = "│" }
opt.list           = true
opt.listchars      = { tab = "→ ", trail = "·", nbsp = "␣", extends = "›", precedes = "‹" }

-- -----------------------------------------------------------------------------
-- Indentation
-- -----------------------------------------------------------------------------
opt.expandtab    = true
opt.tabstop      = 4
opt.softtabstop  = 4
opt.shiftwidth   = 4
opt.shiftround   = true
opt.smartindent  = true
opt.autoindent   = true

-- -----------------------------------------------------------------------------
-- Search
-- -----------------------------------------------------------------------------
opt.ignorecase = true
opt.smartcase  = true
opt.hlsearch   = true
opt.incsearch  = true
opt.inccommand = "split"

-- -----------------------------------------------------------------------------
-- Files / undo / swap
-- -----------------------------------------------------------------------------
opt.swapfile     = false
opt.backup       = false
opt.writebackup  = false
opt.undofile     = true
opt.undodir      = vim.fn.expand("~/.local/share/nvim/undo")
vim.fn.mkdir(vim.fn.expand("~/.local/share/nvim/undo"), "p")

-- -----------------------------------------------------------------------------
-- Catppuccin Mocha colors (manual highlights — no colorscheme plugin)
-- -----------------------------------------------------------------------------
local c = {
    base     = "#1e1e2e",
    mantle   = "#181825",
    crust    = "#11111b",
    text     = "#cdd6f4",
    subtext  = "#a6adc8",
    surface0 = "#313244",
    surface1 = "#45475a",
    surface2 = "#585b70",
    overlay0 = "#6c7086",
    blue     = "#89b4fa",
    sapphire = "#74c7ec",
    teal     = "#94e2d5",
    green    = "#a6e3a1",
    yellow   = "#f9e2af",
    peach    = "#fab387",
    red      = "#f38ba8",
    mauve    = "#cba6f7",
    pink     = "#f5c2e7",
}

local function hi(group, spec) vim.api.nvim_set_hl(0, group, spec) end

vim.cmd("syntax on")
vim.cmd("filetype plugin indent on")

hi("Normal",       { fg = c.text, bg = c.base })
hi("NormalFloat",  { fg = c.text, bg = c.mantle })
hi("FloatBorder",  { fg = c.overlay0, bg = c.mantle })
hi("LineNr",       { fg = c.surface2 })
hi("CursorLineNr", { fg = c.peach, bold = true })
hi("CursorLine",   { bg = c.surface0 })
hi("ColorColumn",  { bg = c.mantle })
hi("SignColumn",   { bg = c.base })
hi("VertSplit",    { fg = c.surface1 })
hi("StatusLine",   { fg = c.text, bg = c.surface0 })
hi("StatusLineNC", { fg = c.subtext, bg = c.mantle })
hi("Pmenu",        { fg = c.text, bg = c.surface0 })
hi("PmenuSel",     { fg = c.base, bg = c.peach, bold = true })
hi("PmenuSbar",    { bg = c.surface1 })
hi("PmenuThumb",   { bg = c.overlay0 })
hi("Visual",       { bg = c.surface1 })
hi("Search",       { fg = c.base, bg = c.yellow })
hi("IncSearch",    { fg = c.base, bg = c.peach })
hi("MatchParen",   { fg = c.peach, bold = true, underline = true })
hi("Comment",      { fg = c.overlay0, italic = true })
hi("Constant",     { fg = c.peach })
hi("String",       { fg = c.green })
hi("Identifier",   { fg = c.text })
hi("Function",     { fg = c.blue })
hi("Statement",    { fg = c.mauve })
hi("Keyword",      { fg = c.mauve })
hi("PreProc",      { fg = c.pink })
hi("Type",         { fg = c.yellow })
hi("Special",      { fg = c.pink })
hi("Error",        { fg = c.red, bold = true })
hi("WarningMsg",   { fg = c.yellow })
hi("Title",        { fg = c.peach, bold = true })
hi("Directory",    { fg = c.blue })
hi("DiffAdd",      { fg = c.green, bg = c.surface0 })
hi("DiffChange",   { fg = c.yellow, bg = c.surface0 })
hi("DiffDelete",   { fg = c.red, bg = c.surface0 })
hi("Whitespace",   { fg = c.surface1 })
hi("NonText",      { fg = c.surface1 })

-- -----------------------------------------------------------------------------
-- Statusline (no plugin — Catppuccin colored segments)
-- -----------------------------------------------------------------------------
hi("StlMode",   { fg = c.base, bg = c.peach,  bold = true })
hi("StlFile",   { fg = c.text, bg = c.surface0 })
hi("StlMid",    { fg = c.text, bg = c.base })
hi("StlInfo",   { fg = c.base, bg = c.teal })
hi("StlPos",    { fg = c.base, bg = c.mauve, bold = true })

vim.opt.statusline = table.concat({
    "%#StlMode# %{toupper(mode())} ",
    "%#StlFile# %f%m%r ",
    "%#StlMid#%=",
    "%#StlInfo# %{&filetype!=''?&filetype:'none'} | %{&fileencoding!=''?&fileencoding:&encoding} ",
    "%#StlPos# %l:%c  %p%% ",
})

-- -----------------------------------------------------------------------------
-- Keymaps
-- vim.keymap.set was added in Neovim 0.7. Older builds (0.5/0.6) must use
-- vim.api.nvim_set_keymap. We pick the right API at runtime.
-- -----------------------------------------------------------------------------
local map
if nvim_at_least(0, 7) then
    map = function(mode, lhs, rhs, desc)
        vim.keymap.set(mode, lhs, rhs, { silent = true, noremap = true, desc = desc })
    end
else
    map = function(mode, lhs, rhs, _desc)
        vim.api.nvim_set_keymap(mode, lhs, rhs, { silent = true, noremap = true })
    end
end

-- Quick save / quit
map("n", "<leader>w", ":w<CR>",  "Save")
map("n", "<leader>q", ":q<CR>",  "Quit")
map("n", "<leader>x", ":x<CR>",  "Save & quit")
map("n", "<leader>h", ":nohlsearch<CR>", "Clear search highlight")

-- Window navigation
map("n", "<C-h>", "<C-w>h")
map("n", "<C-j>", "<C-w>j")
map("n", "<C-k>", "<C-w>k")
map("n", "<C-l>", "<C-w>l")

-- Buffer navigation
map("n", "<S-l>", ":bnext<CR>",     "Next buffer")
map("n", "<S-h>", ":bprevious<CR>", "Prev buffer")
map("n", "<leader>bd", ":bdelete<CR>", "Close buffer")

-- Move lines
map("n", "<A-j>", ":m .+1<CR>==")
map("n", "<A-k>", ":m .-2<CR>==")
map("v", "<A-j>", ":m '>+1<CR>gv=gv")
map("v", "<A-k>", ":m '<-2<CR>gv=gv")

-- Indent in visual mode keeps selection
map("v", "<", "<gv")
map("v", ">", ">gv")

-- Center cursor on jumps
map("n", "<C-d>", "<C-d>zz")
map("n", "<C-u>", "<C-u>zz")
map("n", "n",     "nzzzv")
map("n", "N",     "Nzzzv")

-- Keep cursor centered when jumping by paragraph
map("n", "{", "{zz")
map("n", "}", "}zz")

-- Yank to system clipboard (explicit register) — only effective when
-- there's a clipboard provider; harmless otherwise.
map("n", "<leader>y", '"+y', "Yank to system clipboard")
map("v", "<leader>y", '"+y', "Yank to system clipboard")
map("n", "<leader>p", '"+p', "Paste from system clipboard")

-- Strip trailing whitespace (in addition to BufWritePre auto-strip)
map("n", "<leader>W", ":%s/\\s\\+$//e<CR>", "Strip trailing whitespace")

-- File explorer (built-in netrw)
map("n", "<leader>e", ":Lexplore<CR>", "Toggle file tree")
vim.g.netrw_banner    = 0
vim.g.netrw_liststyle = 3
vim.g.netrw_winsize   = 22

-- -----------------------------------------------------------------------------
-- Autocommands
-- nvim_create_augroup / nvim_create_autocmd with lua callbacks require
-- Neovim 0.7+. On older builds fall back to :autocmd via vim.cmd.
-- -----------------------------------------------------------------------------
if nvim_at_least(0, 7) then
    local aug = vim.api.nvim_create_augroup("NovaShell", { clear = true })

    -- Highlight yanked text
    vim.api.nvim_create_autocmd("TextYankPost", {
        group = aug,
        callback = function() vim.highlight.on_yank({ timeout = 200 }) end,
    })

    -- Trim trailing whitespace on save
    vim.api.nvim_create_autocmd("BufWritePre", {
        group = aug,
        pattern = "*",
        callback = function()
            local save = vim.fn.winsaveview()
            vim.cmd([[%s/\s\+$//e]])
            vim.fn.winrestview(save)
        end,
    })

    -- Restore last cursor position
    vim.api.nvim_create_autocmd("BufReadPost", {
        group = aug,
        callback = function()
            local mark = vim.api.nvim_buf_get_mark(0, '"')
            local lcount = vim.api.nvim_buf_line_count(0)
            if mark[1] > 0 and mark[1] <= lcount then
                pcall(vim.api.nvim_win_set_cursor, 0, mark)
            end
        end,
    })
else
    -- Legacy fallback for nvim 0.5/0.6
    vim.cmd([[
        augroup NovaShell
            autocmd!
            autocmd TextYankPost * silent! lua vim.highlight.on_yank({ timeout = 200 })
            autocmd BufWritePre * let b:_nv_save = winsaveview() | silent! %s/\s\+$//e | call winrestview(b:_nv_save)
            autocmd BufReadPost * if line("'\"") > 1 && line("'\"") <= line("$") | exe "normal! g'\"" | endif
        augroup END
    ]])
end

-- -----------------------------------------------------------------------------
-- External-tool integration (all gated by executable checks — no plugins)
-- -----------------------------------------------------------------------------

-- :Grep pattern  → quickfix list via ripgrep (fallback: grep -R)
vim.api.nvim_create_user_command("Grep", function(args)
    local pattern = args.args
    if pattern == "" then
        vim.notify("Usage: :Grep <pattern>", vim.log.levels.WARN)
        return
    end
    local cmd
    if vim.fn.executable("rg") == 1 then
        cmd = string.format("silent! grep! %q", pattern)
        vim.opt.grepprg = "rg --vimgrep --smart-case --hidden --glob='!.git/**'"
        vim.opt.grepformat = "%f:%l:%c:%m"
    else
        cmd = string.format("silent! grep! -rn %q .", pattern)
        vim.opt.grepprg = "grep -rn"
    end
    vim.cmd(cmd)
    vim.cmd("copen")
    vim.cmd("redraw!")
end, { nargs = "+", desc = "Grep to quickfix (rg if available)" })
vim.keymap = vim.keymap or {}
if nvim_at_least(0, 7) then
    vim.keymap.set("n", "<leader>/", ":Grep ", { desc = "Grep..." })
end

-- :Fzf  → fuzzy file picker via external fzf (no fzf.vim plugin required)
-- Uses Neovim's floating terminal when available; falls back to :!fzf.
if vim.fn.executable("fzf") == 1 and nvim_at_least(0, 7) then
    vim.api.nvim_create_user_command("Fzf", function()
        local buf = vim.api.nvim_create_buf(false, true)
        local w = math.floor(vim.o.columns * 0.8)
        local h = math.floor(vim.o.lines * 0.6)
        local win = vim.api.nvim_open_win(buf, true, {
            relative = "editor", width = w, height = h,
            col = math.floor((vim.o.columns - w) / 2),
            row = math.floor((vim.o.lines - h) / 2),
            style = "minimal", border = "rounded",
        })
        local tmp = vim.fn.tempname()
        local finder = "fd --type f --hidden --follow --exclude .git"
        if vim.fn.executable("fd") == 0 then
            finder = "find . -type f -not -path '*/.git/*'"
        end
        vim.fn.termopen(finder .. " | fzf > " .. vim.fn.shellescape(tmp), {
            on_exit = function()
                pcall(vim.api.nvim_win_close, win, true)
                pcall(vim.api.nvim_buf_delete, buf, { force = true })
                if vim.fn.filereadable(tmp) == 1 then
                    local lines = vim.fn.readfile(tmp)
                    if lines[1] and lines[1] ~= "" then vim.cmd("edit " .. vim.fn.fnameescape(lines[1])) end
                    vim.fn.delete(tmp)
                end
            end,
        })
        vim.cmd("startinsert")
    end, { desc = "Fuzzy-find file via fzf" })
    vim.keymap.set("n", "<leader>f", ":Fzf<CR>", { silent = true, desc = "Find file (fzf)" })
end

-- :Trim — explicit strip (already auto-runs on save, but handy for :range)
vim.api.nvim_create_user_command("Trim", function(args)
    local save = vim.fn.winsaveview()
    local r = args.range == 2 and (args.line1 .. "," .. args.line2) or "%"
    vim.cmd("silent! " .. r .. [[s/\s\+$//e]])
    vim.fn.winrestview(save)
end, { range = "%", desc = "Strip trailing whitespace" })

-- Terminal-mode escape: Esc exits to normal mode
if nvim_at_least(0, 7) then
    vim.keymap.set("t", "<Esc>", [[<C-\><C-n>]], { desc = "Exit terminal mode" })
end

-- -----------------------------------------------------------------------------
-- Optional LSP: only activates if a language server is on PATH.
-- No plugin manager, no Mason — pure `vim.lsp.start`. Requires nvim 0.8+.
-- Currently wires up bash (bash-language-server) and lua (lua-language-server).
-- -----------------------------------------------------------------------------
if nvim_at_least(0, 8) and vim.lsp and vim.lsp.start then
    local function start_lsp(name, cmd, ft)
        if vim.fn.executable(cmd[1]) ~= 1 then return end
        vim.api.nvim_create_autocmd("FileType", {
            pattern = ft,
            callback = function()
                vim.lsp.start({
                    name = name, cmd = cmd,
                    root_dir = vim.fs.dirname(vim.fs.find({ ".git" }, { upward = true })[1] or vim.fn.getcwd()),
                })
            end,
        })
    end
    start_lsp("bashls", { "bash-language-server", "start" }, { "sh", "bash" })
    start_lsp("luals",  { "lua-language-server" },           { "lua" })

    -- Minimal LSP keymaps — only active when a client is attached.
    vim.api.nvim_create_autocmd("LspAttach", {
        callback = function(ev)
            local o = { buffer = ev.buf, silent = true }
            vim.keymap.set("n", "gd",         vim.lsp.buf.definition,      o)
            vim.keymap.set("n", "gr",         vim.lsp.buf.references,      o)
            vim.keymap.set("n", "K",          vim.lsp.buf.hover,           o)
            vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename,          o)
            vim.keymap.set("n", "<leader>ca", vim.lsp.buf.code_action,     o)
            vim.keymap.set("n", "[d",         vim.diagnostic.goto_prev,    o)
            vim.keymap.set("n", "]d",         vim.diagnostic.goto_next,    o)
        end,
    })
end

-- -----------------------------------------------------------------------------
-- Treesitter: enable default highlight group only. Parsers must already exist
-- on disk (we never fetch). Neovim 0.9+ ships many parsers in core.
-- -----------------------------------------------------------------------------
if nvim_at_least(0, 9) and vim.treesitter and vim.treesitter.start then
    vim.api.nvim_create_autocmd("FileType", {
        pattern = { "lua", "bash", "sh", "python", "vim", "yaml", "json", "markdown" },
        callback = function(args)
            pcall(vim.treesitter.start, args.buf)
        end,
    })
end
