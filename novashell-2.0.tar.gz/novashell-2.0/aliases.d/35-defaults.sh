# NovaShell aliases.d/35-defaults — improved defaults

alias mkdir='mkdir -pv'
alias wget='wget -c'
alias df='df -hT'
alias du='du -h'
alias free='free -h'
alias less='less -R'
alias more='less -R'
alias nano='vim'
alias vi='vim'
alias mount='mount | column -t'
