# NovaShell aliases.d/65-disk — disk / filesystem

findmnt --real &>/dev/null && alias mounts='findmnt --real' || alias mounts='mount | column -t'
alias lsblk='lsblk -f'
alias dfh='df -hT | grep -v tmpfs | grep -v loop'
alias duh='du -sh * 2>/dev/null | sort -h'
alias duf='du -sh ./* 2>/dev/null | sort -h'
alias biggest='du -sh * 2>/dev/null | sort -rh | head -20'
alias usage='df -hT; echo ""; free -h'
alias inodes='df -i'
