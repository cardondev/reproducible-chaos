# NovaShell aliases.d/45-firewall — firewalld (RHEL 7-10)

alias fwlist='sudo firewall-cmd --list-all'
alias fwzones='sudo firewall-cmd --get-zones'
alias fwactive='sudo firewall-cmd --get-active-zones'
alias fwservices='sudo firewall-cmd --get-services'
alias fwreload='sudo firewall-cmd --reload'
alias fwperm='sudo firewall-cmd --permanent'
alias fwruntime='sudo firewall-cmd'
