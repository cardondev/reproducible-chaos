# NovaShell aliases.d/15-modern — modern tool replacements (only if present)
# RHEL 7: none of these ship. Fall through cleanly.

command -v bat  &>/dev/null && alias cat='bat --paging=never'
command -v bat  &>/dev/null && alias less='bat --paging=always'
command -v htop &>/dev/null && alias top='htop'
command -v eza  &>/dev/null && alias ll='eza -lah --group-directories-first --icons=auto'
