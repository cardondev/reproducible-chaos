# NovaShell aliases.d/00-colors — color flags for core commands
# Compatible RHEL 7-10. Feature-detected where flags differ.

alias ls='ls --color=auto'
alias grep='grep --color=auto'
alias fgrep='fgrep --color=auto'
alias egrep='egrep --color=auto'
diff --color=auto /dev/null /dev/null &>/dev/null && alias diff='diff --color=auto'
ip -color=auto route &>/dev/null && alias ip='ip -color=auto'
dmesg --color=auto &>/dev/null && alias dmesg='dmesg --color=auto'
