# NovaShell aliases.d/50-package — dnf/yum (RHEL 7 uses yum, 8+ uses dnf)
# Prefer dnf when present, fall through to yum otherwise.

if command -v dnf &>/dev/null; then
    _NS_PKG=dnf
else
    _NS_PKG=yum
fi

alias update="sudo $_NS_PKG update -y"
alias upgrade="sudo $_NS_PKG upgrade -y"
alias install="sudo $_NS_PKG install -y"
alias remove="sudo $_NS_PKG remove -y"
alias search="$_NS_PKG search"
alias pkginfo="$_NS_PKG info"
alias pkglist="$_NS_PKG list installed"
alias pkgclean="sudo $_NS_PKG clean all"
alias repolist="$_NS_PKG repolist"
alias whatprovides="$_NS_PKG provides"
alias historyp="sudo $_NS_PKG history"

unset _NS_PKG
