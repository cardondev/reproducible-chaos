# NovaShell aliases.d/40-network — networking

alias ports='ss -tulpn'
alias listen='ss -tulpn | grep LISTEN'
alias connections='ss -tup'
alias myip='hostname -I | awk "{print \$1}"'
alias pubip='curl -s ifconfig.me 2>/dev/null || echo "No internet access"'
alias ping='ping -c 5'
alias fastping='ping -c 50 -i 0.2'
alias flushdns='systemctl restart systemd-resolved 2>/dev/null || systemctl restart nscd 2>/dev/null || echo "No DNS cache service found"'
alias ns='nslookup'
alias nst='netstat -tulpn 2>/dev/null || ss -tulpn'
alias route='ip route'
alias arp='ip neigh'

# `ip -brief` is RHEL 8+ (iproute2 >= 4.16). Fall back on RHEL 7.
if ip -brief addr &>/dev/null; then
    alias ipbrief='ip -brief addr'
    alias routebrief='ip -brief route'
else
    alias ipbrief='ip -4 addr show | awk "/inet /{print}"'
    alias routebrief='ip route'
fi
