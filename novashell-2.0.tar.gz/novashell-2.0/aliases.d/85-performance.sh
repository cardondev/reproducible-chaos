# NovaShell aliases.d/85-performance — monitoring / perf

alias vmstat='vmstat 1 5'
alias iostat='iostat -xz 1 5 2>/dev/null || echo "sysstat not installed"'
alias sar='sar -u 1 5 2>/dev/null || echo "sysstat not installed"'
alias meminfo='cat /proc/meminfo'
alias cpuinfo='lscpu'
alias loadavg='cat /proc/loadavg'
alias temps='sensors 2>/dev/null || echo "lm_sensors not installed"'
