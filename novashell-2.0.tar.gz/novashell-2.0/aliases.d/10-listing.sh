# NovaShell aliases.d/10-listing — directory listing

alias ll='ls -lAhF --group-directories-first'
alias la='ls -A'
alias l='ls -CF'
alias lt='ls -lAhFtr'
alias lS='ls -lAhFS'
alias lsd='ls -d */ 2>/dev/null'
alias lsf='ls -p | grep -v /'
