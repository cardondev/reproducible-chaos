# NovaShell aliases.d/94-tmux — tmux (works with both native and prefix modes)

if [[ "${NOVASHELL_MODE:-native}" == "native" ]]; then
    alias tmux='tmux -f "$HOME/.tmux.conf"'
else
    alias tmux='tmux -f "$HOME/${NOVASHELL_PREFIX}_tmux.conf"'
fi
alias ta='tmux attach -t'
alias tl='tmux list-sessions'
alias tn='tmux new -s'
alias tk='tmux kill-session -t'
alias tka='tmux kill-server'
alias td='tmux detach'
