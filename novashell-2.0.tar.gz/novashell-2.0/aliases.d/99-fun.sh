# NovaShell aliases.d/99-fun — novelty
alias turbo='turbo_mode'
alias matrix='echo -e "\e[32m"; while :; do printf "%$((RANDOM % COLUMNS))s" "$((RANDOM % 2))"; done'
alias busy='cat /dev/urandom | hexdump -C | grep "ca fe"'
