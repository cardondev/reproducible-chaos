# NovaShell aliases.d/30-safety — safety nets

# rm: use -I when coreutils supports it, else -i. --preserve-root exists on all.
rm --help 2>&1 | grep -q '\-I' && alias rm='rm -I --preserve-root' || alias rm='rm -i --preserve-root'
alias cp='cp -i'
alias mv='mv -i'
alias ln='ln -i'
alias chown='chown --preserve-root'
alias chmod='chmod --preserve-root'
alias chgrp='chgrp --preserve-root'
