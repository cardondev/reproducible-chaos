# NovaShell aliases.d/98-edit — quick edit of configs
# Uses $EDITOR. `vnvim` jumps into nvim init.lua when nvim is present.

if [[ "${NOVASHELL_MODE:-native}" == "native" ]]; then
    alias vbash='${EDITOR:-vim} "$HOME/.bashrc"'
    alias valias='${EDITOR:-vim} "$HOME/.bash_aliases"'
    alias vfunc='${EDITOR:-vim} "$HOME/.bash_functions"'
    alias vvim='${EDITOR:-vim} "$HOME/.vimrc"'
    alias vtmux='${EDITOR:-vim} "$HOME/.tmux.conf"'
else
    alias vbash='${EDITOR:-vim} "$HOME/${NOVASHELL_PREFIX}_bashrc"'
    alias valias='${EDITOR:-vim} "$HOME/${NOVASHELL_PREFIX}_aliases"'
    alias vfunc='${EDITOR:-vim} "$HOME/${NOVASHELL_PREFIX}_functions"'
    alias vvim='${EDITOR:-vim} "$HOME/${NOVASHELL_PREFIX}_vimrc"'
    alias vtmux='${EDITOR:-vim} "$HOME/${NOVASHELL_PREFIX}_tmux.conf"'
fi
command -v nvim &>/dev/null && alias vnvim='nvim "$HOME/.config/nvim/init.lua"'
