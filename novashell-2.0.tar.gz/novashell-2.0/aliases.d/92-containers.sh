# NovaShell aliases.d/92-containers — docker / podman
# RHEL 7: docker only. RHEL 8+: podman is standard; docker may exist.

command -v podman &>/dev/null && ! command -v docker &>/dev/null && alias docker='podman'
alias dps='docker ps --format "table {{.ID}}\t{{.Names}}\t{{.Status}}\t{{.Ports}}"'
alias dpsa='docker ps -a --format "table {{.ID}}\t{{.Names}}\t{{.Status}}\t{{.Ports}}"'
alias dimg='docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}\t{{.CreatedSince}}"'
alias dclean='docker system prune -af'
alias dlogs='docker logs -f'
alias dsize='docker system df'
alias dvols='docker volume ls'
alias dnets='docker network ls'
