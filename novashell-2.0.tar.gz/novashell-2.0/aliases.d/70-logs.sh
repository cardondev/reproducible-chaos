# NovaShell aliases.d/70-logs — system log tails

alias logs='sudo journalctl -xe'
alias syslog='sudo tail -f /var/log/messages'
alias authlog='sudo tail -f /var/log/secure'
alias bootlog='sudo journalctl -b'
alias kernlog='sudo dmesg -T | tail -50'
alias auditlog='sudo tail -f /var/log/audit/audit.log'
alias lastlog='last -20'
alias faillog='sudo faillock --user'
alias logwatch='sudo tail -f /var/log/messages /var/log/secure /var/log/audit/audit.log'
