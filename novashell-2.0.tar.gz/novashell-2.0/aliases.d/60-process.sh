# NovaShell aliases.d/60-process — process management

alias psa='ps auxf'
alias psg='ps aux | grep -v grep | grep -i'
alias psmem='ps aux --sort=-%mem | head -20'
alias pscpu='ps aux --sort=-%cpu | head -20'
alias pstree='pstree -p'
alias zombies='ps aux | awk '"'"'{if ($8 ~ /^Z/) print}'"'"''
