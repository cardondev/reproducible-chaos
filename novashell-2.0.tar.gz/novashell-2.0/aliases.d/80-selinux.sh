# NovaShell aliases.d/80-selinux — SELinux

alias sestat='getenforce'
alias semode='sudo setenforce'
alias sebool='getsebool -a'
alias secontext='ls -laZ'
alias seaudit='sudo ausearch -m AVC -ts recent'
alias sealerts='sudo sealert -a /var/log/audit/audit.log 2>/dev/null || echo "setroubleshoot not installed"'
alias serestore='sudo restorecon -R -v'
