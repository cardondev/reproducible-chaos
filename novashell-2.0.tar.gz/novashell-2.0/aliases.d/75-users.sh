# NovaShell aliases.d/75-users — user / permission helpers

alias userlist='cut -d: -f1 /etc/passwd | sort'
alias grouplist='cut -d: -f1 /etc/group | sort'
alias sudoers='sudo cat /etc/sudoers'
alias mygroups='groups $(whoami)'
alias lastlogin='lastlog | grep -v "Never"'
alias whoisloggedin='w'
alias userinfo='id'
