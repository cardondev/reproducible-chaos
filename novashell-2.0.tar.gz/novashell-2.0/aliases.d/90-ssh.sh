# NovaShell aliases.d/90-ssh — SSH

alias sshl='cat ~/.ssh/config 2>/dev/null | grep -i "^host " | awk "{print \$2}"'
alias sshkey='cat ~/.ssh/id_ed25519.pub 2>/dev/null || cat ~/.ssh/id_rsa.pub 2>/dev/null || echo "No SSH key found"'
alias sshgen='ssh-keygen -t ed25519 -C "$(whoami)@$(hostname)-$(date +%Y%m%d)"'
alias sshfp='ssh-keygen -l -f'
alias sshadd='eval "$(ssh-agent -s)" && ssh-add'
alias sshconf='${EDITOR:-vim} ~/.ssh/config'
