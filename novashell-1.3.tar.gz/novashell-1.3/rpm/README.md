# NovaShell RPM Packaging

RPM packaging for NovaShell v1.2. Builds `noarch` RPMs for EL7, EL8, EL9, and EL10.

## Directory Structure

```
novashell_rpm/
├── SPECS/novashell.spec                          <- RPM spec file
├── SOURCES/novashell-1.2.tar.gz                  <- Source tarball (auto-generated)
├── BUILD/                                        <- Build workspace (auto-generated)
├── RPMS/noarch/novashell-1.2-1.el{7,8,9,10}.noarch.rpm <- Built RPMs
├── SRPMS/novashell-1.2-1.src.rpm                 <- Source RPM
├── rpm-helper.sh                                 <- Per-user install/restore logic
├── LICENSE                                       <- MIT license
├── build-rpm.sh                                  <- Build script
└── README.md                                     <- This file
```

## Building the RPM

```bash
bash build-rpm.sh
```

This will:
1. Install `rpm-build` if not already present
2. Create a source tarball from the `../dotfiles/` directory
3. Run `rpmbuild` to produce the RPM

The output RPM will be in `RPMS/noarch/`.

### Build Requirements

- `rpm-build` (installed automatically by the build script)
- The `../dotfiles/` directory must contain the NovaShell source files

## Installing

```bash
sudo dnf install RPMS/noarch/novashell-1.0-1.el9.noarch.rpm
```

Or copy the RPM to another system and install there:

```bash
scp RPMS/noarch/novashell-1.0-1.el9.noarch.rpm user@remote:/tmp/
ssh user@remote 'sudo dnf install /tmp/novashell-1.0-1.el9.noarch.rpm'
```

### What Happens on Install

1. NovaShell files are placed in `/usr/share/novashell/`
2. The helper script `/usr/libexec/novashell/rpm-helper.sh` runs for the invoking user
3. Existing files are backed up to `~/.novashell_backup_rpm/`
   - `.bashrc`, `.bash_profile`, `.vimrc`, `.tmux.conf` (whatever exists)
   - A `restore.sh` script is created in the backup directory
4. NovaShell config is deployed in native mode:
   - `~/.bashrc` — main shell config
   - `~/.bash_profile` — login session logging
   - `~/.bash_aliases` — command aliases
   - `~/.bash_functions` — shell functions
   - `~/.vimrc` — vim config
   - `~/.tmux.conf` — tmux config
5. `~/.vim/undodir` is created for persistent vim undo

### Activating for Additional Users

The RPM post-install scriptlet automatically configures the user who ran `sudo dnf install`. To activate for other users:

```bash
# As the target user:
/usr/libexec/novashell/rpm-helper.sh install
```

Or use the interactive deploy script for native/prefix mode selection:

```bash
bash /usr/share/novashell/deploy.sh
```

## Removing

```bash
sudo dnf remove novashell
```

### What Happens on Remove

1. The pre-uninstall scriptlet runs `rpm-helper.sh restore` for the invoking user
2. Original files are restored from `~/.novashell_backup_rpm/`
3. If no backup exists (fresh system), the NovaShell config files are removed
4. RPM files are removed from `/usr/share/novashell/` and `/usr/libexec/novashell/`
5. The backup directory `~/.novashell_backup_rpm/` is preserved (not deleted)

### Restoring Other Users

If multiple users had NovaShell installed, each user should restore manually before the RPM is removed:

```bash
# As the target user:
/usr/libexec/novashell/rpm-helper.sh restore
```

Or run the backup restore script directly:

```bash
bash ~/.novashell_backup_rpm/restore.sh
```

## Upgrading

```bash
sudo dnf upgrade novashell-1.1-1.el9.noarch.rpm
```

RPM upgrades (`$1 > 0` in scriptlets) do **not** trigger the restore logic. The new version overwrites the NovaShell config files while preserving the original backup from the first install.

## EL7 / EL8 / EL9 Compatibility

Separate RPMs are built for each EL version with appropriate dist tags and dependency handling.

| Component | EL7 | EL8 | EL9 | EL10 |
|---|---|---|---|---|
| RPM installs | Yes | Yes | Yes | Yes |
| bash 4.0+ | Yes (4.2) | Yes (4.4) | Yes (5.1) | Yes (5.2) |
| vim-enhanced | Yes | Yes | Yes | Yes |
| tmux (recommended) | Yes | Yes | Yes | Yes |
| fzf (recommended) | EPEL 7 | EPEL 8 | EPEL 9 | Base |
| bat (recommended) | No | EPEL 8 | EPEL 9 | Base |
| fd-find (recommended) | No | EPEL 8 | EPEL 9 | Base |
| ripgrep (recommended) | No | EPEL 8 | EPEL 9 | Base |
| htop (recommended) | EPEL 7 | EPEL 8 | EPEL 9 | Base |

The RPM uses `Recommends` (not `Requires`) for optional tools. They are not needed for NovaShell to function — features that depend on them (fzf-powered functions, bat previews) are guarded with `command -v` checks and simply won't activate if the tool isn't present.

The `.el9` in the RPM filename is a dist tag from the build host. It does **not** restrict which EL version can install it. To build with a different dist tag:

```bash
rpmbuild --define "_topdir $(pwd)" --define "dist .el8" -ba SPECS/novashell.spec
```

Or remove the dist tag entirely:

```bash
rpmbuild --define "_topdir $(pwd)" --define "dist %{nil}" -ba SPECS/novashell.spec
```

## RPM Details

| Field | Value |
|---|---|
| Name | `novashell` |
| Version | `1.2` |
| Architecture | `noarch` |
| License | MIT |
| Hard requires | `bash >= 4.0`, `vim-enhanced` |
| Soft recommends | `tmux`, `fzf`, `bat`, `fd-find`, `ripgrep`, `htop` |
| Install location | `/usr/share/novashell/`, `/usr/libexec/novashell/` |
| User config | `~/.*` (native mode deployment) |
| Backup location | `~/.novashell_backup_rpm/` |

## Files Installed by RPM

| Path | Purpose |
|---|---|
| `/usr/share/novashell/bashrc` | Shell config source |
| `/usr/share/novashell/bash_profile` | Login session logging source |
| `/usr/share/novashell/aliases` | Aliases source |
| `/usr/share/novashell/functions` | Functions source |
| `/usr/share/novashell/vimrc` | Vim config source |
| `/usr/share/novashell/tmux.conf` | Tmux config source |
| `/usr/share/novashell/deploy.sh` | Interactive installer (native/prefix modes) |
| `/usr/share/novashell/README.md` | Documentation |
| `/usr/libexec/novashell/rpm-helper.sh` | Per-user install/restore helper |
| `/usr/share/licenses/novashell/LICENSE` | MIT license |
| `/usr/share/doc/novashell/README.md` | Documentation (RPM doc) |
