Name:           novashell
Version:        1.3
Release:        1%{?dist}
Summary:        NovaShell - Terminal configuration with Catppuccin Mocha theme
License:        MIT
URL:            https://github.com/QuantumMindLabs/novashell
BuildArch:      noarch
Source0:        %{name}-%{version}.tar.gz

Requires:       bash >= 4.0
Requires:       vim-enhanced

# Recommends is only supported on RHEL 8+ (RPM 4.13+)
# On RHEL 7 these are silently ignored; use Suggests as fallback
%if 0%{?rhel} >= 8 || 0%{?fedora}
Recommends:     tmux
Recommends:     fzf
Recommends:     htop
Recommends:     bat
Recommends:     fd-find
Recommends:     ripgrep
%endif

%description
NovaShell is a self-contained terminal configuration for RHEL/Rocky/AlmaLinux
systems. Features include a Catppuccin Mocha color theme, animated prompt,
160+ aliases, 40+ utility functions, PuTTY ASCII fallback, login session
logging, and system health checks.

Installs in native mode: replaces .bashrc, .bash_profile, .vimrc, .tmux.conf.
Original files are backed up to ~/.novashell_backup_<timestamp>/ with a
restore script. Removing this package restores the originals automatically.

%prep
%setup -q

%build
# Nothing to build — config files only

%install
rm -rf %{buildroot}

# Install source files to /usr/share/novashell
install -d %{buildroot}%{_datadir}/%{name}
install -m 644 bashrc         %{buildroot}%{_datadir}/%{name}/bashrc
install -m 644 bash_profile   %{buildroot}%{_datadir}/%{name}/bash_profile
install -m 644 aliases        %{buildroot}%{_datadir}/%{name}/aliases
install -m 644 functions      %{buildroot}%{_datadir}/%{name}/functions
install -m 644 vimrc          %{buildroot}%{_datadir}/%{name}/vimrc
install -m 644 tmux.conf      %{buildroot}%{_datadir}/%{name}/tmux.conf
install -m 755 deploy.sh      %{buildroot}%{_datadir}/%{name}/deploy.sh
install -m 644 README.md      %{buildroot}%{_datadir}/%{name}/README.md

# Install the RPM helper script
install -d %{buildroot}%{_libexecdir}/%{name}
install -m 755 rpm-helper.sh  %{buildroot}%{_libexecdir}/%{name}/rpm-helper.sh

%files
%license LICENSE
%doc README.md
%{_datadir}/%{name}/
%{_libexecdir}/%{name}/

%pre
# Pre-install: nothing needed (backup happens in %post)

%post
# Post-install: deploy for the invoking user
# Works for both 'sudo dnf install' (SUDO_USER set) and direct root installs
INVOKING_USER="${SUDO_USER:-}"
if [[ -n "$INVOKING_USER" ]] && [[ "$INVOKING_USER" != "root" ]] && id "$INVOKING_USER" &>/dev/null; then
    su - "$INVOKING_USER" -c "%{_libexecdir}/%{name}/rpm-helper.sh install" || true
fi
# Always show activation instructions (useful for root or additional users)
echo ""
echo "NovaShell installed to %{_datadir}/%{name}/"
echo ""
echo "To activate for any user, run as that user:"
echo "  %{_libexecdir}/%{name}/rpm-helper.sh install"
echo ""

%preun
# Pre-uninstall: restore original files (only on full remove, not upgrade)
if [ "$1" -eq 0 ]; then
    INVOKING_USER="${SUDO_USER:-}"
    if [[ -n "$INVOKING_USER" ]] && [[ "$INVOKING_USER" != "root" ]] && id "$INVOKING_USER" &>/dev/null; then
        su - "$INVOKING_USER" -c "%{_libexecdir}/%{name}/rpm-helper.sh restore" || true
    fi
    echo ""
    echo "To restore original config for any user, run as that user:"
    echo "  %{_libexecdir}/%{name}/rpm-helper.sh restore"
    echo ""
fi

%postun
# Post-uninstall: cleanup (only on full remove, not upgrade)
if [ "$1" -eq 0 ]; then
    echo "NovaShell removed. Log back in or run 'source ~/.bashrc' to reload."
fi

%changelog
* Thu Apr 02 2026 Quantum Mind Labs <quantummindlabs@proton.me> - 1.3-1
- Removed all git integration (prompt helper, aliases) to fix performance
  issues in cloned repos where git commands caused slow responses
- Rewrote loop/keepalive function for RHEL 7/8 compatibility (CTRL+C works)
- Fixed RPM re-deployment: root can now reinstall after regular user install
- Added blinking block cursor to prompt for visible typing position
- Changed vim cursorline highlight to lighter color for better contrast
- Build script now cleans previous artifacts before rebuilding

* Thu Apr 02 2026 Quantum Mind Labs <quantummindlabs@proton.me> - 1.2-1
- Changed command separator pattern from =-= to ==== for cleaner visual breaks
- Added RHEL 10 support and compatibility
- Fixed build script path references and multi-target RPM build
- Cleaned up repository structure (removed duplicate files)
- Fixed LICENSE consistency across repo and RPM packaging
- Updated project URL to QuantumMindLabs organization

* Wed Apr 01 2026 Quantum Mind Labs <quantummindlabs@proton.me> - 1.1-1
- RHEL 7/8/9 compatibility: guard color flags, shopt, package detection
- Vim: OLED black background, version-guarded Lexplore/FocusGained/completeopt
- Loop alias refreshes time in-place instead of stacking lines
- RPM spec: conditional Recommends for RHEL 7 compatibility
- Simplified file headers

* Mon Mar 25 2026 Quantum Mind Labs <quantummindlabs@proton.me> - 1.0-1
- Initial release
- Catppuccin Mocha theme with PuTTY ASCII fallback
- Animated italic prompt arrows with git status
- 160+ aliases for RHEL/Rocky system administration
- 40+ utility functions including healthcheck, sysinfo, svc helper
- Login session logging via bash_profile
- FZF/bat/fd integration (optional)
- Native and prefix installation modes
- RPM packaging with automatic backup and restore on remove
