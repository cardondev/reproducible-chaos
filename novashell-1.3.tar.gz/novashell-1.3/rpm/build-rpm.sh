#!/bin/bash
# BUILD-RPM - NovaShell

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
VERSION="1.3"
NAME="novashell"

GREEN='\e[38;5;151m'
CYAN='\e[38;5;116m'
YELLOW='\e[38;5;223m'
RED='\e[38;5;203m'
RESET='\e[0m'

echo -e "${CYAN}=== Building NovaShell v${VERSION} RPM ===${RESET}"
echo ""

# Check for rpmbuild
if ! command -v rpmbuild &>/dev/null; then
    echo -e "${YELLOW}rpmbuild not found. Installing rpm-build...${RESET}"
    if command -v dnf &>/dev/null; then
        sudo dnf install -y rpm-build 2>&1 | tail -3
    else
        sudo yum install -y rpm-build 2>&1 | tail -3
    fi
fi

# Create tarball (the source RPM expects)
echo -e "${CYAN}Creating source tarball...${RESET}"
TARBALL_DIR="${NAME}-${VERSION}"
WORK_DIR=$(mktemp -d)

mkdir -p "$WORK_DIR/$TARBALL_DIR"

# Copy source files
for f in bashrc bash_profile aliases functions vimrc tmux.conf deploy.sh; do
    cp "$REPO_DIR/src/$f" "$WORK_DIR/$TARBALL_DIR/"
done

# Copy repo-level files
cp "$REPO_DIR/README.md" "$WORK_DIR/$TARBALL_DIR/"
cp "$REPO_DIR/LICENSE" "$WORK_DIR/$TARBALL_DIR/"

# Copy RPM-specific files
cp "$SCRIPT_DIR/rpm-helper.sh" "$WORK_DIR/$TARBALL_DIR/"

# Build output directory
BUILD_DIR="${BUILD_BASE:-$REPO_DIR/../novashell_rpm}"
BUILD_DIR="$(mkdir -p "$BUILD_DIR" && cd "$BUILD_DIR" && pwd)"

# Clean previous build artifacts so any user/root can rebuild
rm -rf "$BUILD_DIR"/{BUILD,BUILDROOT,RPMS,SOURCES,SPECS,SRPMS}

# Create rpmbuild directory structure
mkdir -p "$BUILD_DIR"/{BUILD,BUILDROOT,RPMS,SOURCES,SPECS,SRPMS}

# Create tarball
tar -czf "$BUILD_DIR/SOURCES/${NAME}-${VERSION}.tar.gz" -C "$WORK_DIR" "$TARBALL_DIR"
rm -rf "$WORK_DIR"

echo -e "${GREEN}  Created: SOURCES/${NAME}-${VERSION}.tar.gz${RESET}"

# Copy spec file
cp "$SCRIPT_DIR/${NAME}.spec" "$BUILD_DIR/SPECS/"

# Build RPMs for each RHEL target
TARGETS="${BUILD_TARGETS:-7 8 9 10}"

for RHEL_VER in $TARGETS; do
    echo ""
    echo -e "${CYAN}Building RPM for RHEL ${RHEL_VER}...${RESET}"
    rpmbuild \
        --define "_topdir $BUILD_DIR" \
        --define "dist .el${RHEL_VER}" \
        --define "rhel ${RHEL_VER}" \
        -bb "$BUILD_DIR/SPECS/${NAME}.spec"
done

# Build source RPM (once, untagged)
echo ""
echo -e "${CYAN}Building source RPM...${RESET}"
rpmbuild \
    --define "_topdir $BUILD_DIR" \
    -bs "$BUILD_DIR/SPECS/${NAME}.spec"

echo ""
echo -e "${GREEN}=== Build Complete ===${RESET}"
echo ""

# Find and display the built RPMs
echo "Built packages:"
find "$BUILD_DIR/RPMS" -name "*.rpm" -exec echo -e "  ${GREEN}{}${RESET}" \;
find "$BUILD_DIR/SRPMS" -name "*.rpm" -exec echo -e "  ${YELLOW}{}${RESET}" \;

echo ""
echo "Install with:"
echo -e "  ${CYAN}sudo dnf install <path-to-rpm>${RESET}"
echo ""
echo "Remove with:"
echo -e "  ${CYAN}sudo dnf remove ${NAME}${RESET}"
