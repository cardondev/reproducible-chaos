-- =============================================================================
-- INIT.LUA - NovaShell Neovim Configuration
-- Theme: Catppuccin Mocha (hardcoded — no plugins, no network, no git)
-- Optional component: only deployed when `nvim` is present on the system.
-- =============================================================================

-- Leader
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- -----------------------------------------------------------------------------
-- General
-- -----------------------------------------------------------------------------
local opt = vim.opt
opt.encoding       = "utf-8"
opt.fileencoding   = "utf-8"
opt.ttyfast        = true
opt.lazyredraw     = true
opt.updatetime     = 250
opt.timeoutlen     = 500
opt.history        = 1000
opt.undolevels     = 1000
opt.backspace      = { "indent", "eol", "start" }
opt.hidden         = true
opt.mouse          = "a"
opt.clipboard      = "unnamedplus"
opt.confirm        = true
opt.shortmess:append("c")
opt.shortmess:append("I")  -- no intro

-- -----------------------------------------------------------------------------
-- Display
-- -----------------------------------------------------------------------------
opt.number         = true
opt.relativenumber = true
opt.ruler          = true
opt.cursorline     = true
opt.showmatch      = true
opt.matchtime      = 2
opt.wrap           = false
opt.linebreak      = true
opt.scrolloff      = 8
opt.sidescrolloff  = 8
opt.signcolumn     = "yes"
opt.colorcolumn    = "100"
opt.termguicolors  = true
opt.showmode       = false
opt.laststatus     = 2
opt.cmdheight      = 1
opt.pumheight      = 12
opt.splitright     = true
opt.splitbelow     = true
opt.fillchars      = { eob = " ", vert = "│" }
opt.list           = true
opt.listchars      = { tab = "→ ", trail = "·", nbsp = "␣", extends = "›", precedes = "‹" }

-- -----------------------------------------------------------------------------
-- Indentation
-- -----------------------------------------------------------------------------
opt.expandtab    = true
opt.tabstop      = 4
opt.softtabstop  = 4
opt.shiftwidth   = 4
opt.shiftround   = true
opt.smartindent  = true
opt.autoindent   = true

-- -----------------------------------------------------------------------------
-- Search
-- -----------------------------------------------------------------------------
opt.ignorecase = true
opt.smartcase  = true
opt.hlsearch   = true
opt.incsearch  = true
opt.inccommand = "split"

-- -----------------------------------------------------------------------------
-- Files / undo / swap
-- -----------------------------------------------------------------------------
opt.swapfile     = false
opt.backup       = false
opt.writebackup  = false
opt.undofile     = true
opt.undodir      = vim.fn.expand("~/.local/share/nvim/undo")
vim.fn.mkdir(vim.fn.expand("~/.local/share/nvim/undo"), "p")

-- -----------------------------------------------------------------------------
-- Catppuccin Mocha colors (manual highlights — no colorscheme plugin)
-- -----------------------------------------------------------------------------
local c = {
    base     = "#1e1e2e",
    mantle   = "#181825",
    crust    = "#11111b",
    text     = "#cdd6f4",
    subtext  = "#a6adc8",
    surface0 = "#313244",
    surface1 = "#45475a",
    surface2 = "#585b70",
    overlay0 = "#6c7086",
    blue     = "#89b4fa",
    sapphire = "#74c7ec",
    teal     = "#94e2d5",
    green    = "#a6e3a1",
    yellow   = "#f9e2af",
    peach    = "#fab387",
    red      = "#f38ba8",
    mauve    = "#cba6f7",
    pink     = "#f5c2e7",
}

local function hi(group, spec) vim.api.nvim_set_hl(0, group, spec) end

vim.cmd("syntax on")
vim.cmd("filetype plugin indent on")

hi("Normal",       { fg = c.text, bg = c.base })
hi("NormalFloat",  { fg = c.text, bg = c.mantle })
hi("FloatBorder",  { fg = c.overlay0, bg = c.mantle })
hi("LineNr",       { fg = c.surface2 })
hi("CursorLineNr", { fg = c.peach, bold = true })
hi("CursorLine",   { bg = c.surface0 })
hi("ColorColumn",  { bg = c.mantle })
hi("SignColumn",   { bg = c.base })
hi("VertSplit",    { fg = c.surface1 })
hi("StatusLine",   { fg = c.text, bg = c.surface0 })
hi("StatusLineNC", { fg = c.subtext, bg = c.mantle })
hi("Pmenu",        { fg = c.text, bg = c.surface0 })
hi("PmenuSel",     { fg = c.base, bg = c.peach, bold = true })
hi("PmenuSbar",    { bg = c.surface1 })
hi("PmenuThumb",   { bg = c.overlay0 })
hi("Visual",       { bg = c.surface1 })
hi("Search",       { fg = c.base, bg = c.yellow })
hi("IncSearch",    { fg = c.base, bg = c.peach })
hi("MatchParen",   { fg = c.peach, bold = true, underline = true })
hi("Comment",      { fg = c.overlay0, italic = true })
hi("Constant",     { fg = c.peach })
hi("String",       { fg = c.green })
hi("Identifier",   { fg = c.text })
hi("Function",     { fg = c.blue })
hi("Statement",    { fg = c.mauve })
hi("Keyword",      { fg = c.mauve })
hi("PreProc",      { fg = c.pink })
hi("Type",         { fg = c.yellow })
hi("Special",      { fg = c.pink })
hi("Error",        { fg = c.red, bold = true })
hi("WarningMsg",   { fg = c.yellow })
hi("Title",        { fg = c.peach, bold = true })
hi("Directory",    { fg = c.blue })
hi("DiffAdd",      { fg = c.green, bg = c.surface0 })
hi("DiffChange",   { fg = c.yellow, bg = c.surface0 })
hi("DiffDelete",   { fg = c.red, bg = c.surface0 })
hi("Whitespace",   { fg = c.surface1 })
hi("NonText",      { fg = c.surface1 })

-- -----------------------------------------------------------------------------
-- Statusline (no plugin — Catppuccin colored segments)
-- -----------------------------------------------------------------------------
hi("StlMode",   { fg = c.base, bg = c.peach,  bold = true })
hi("StlFile",   { fg = c.text, bg = c.surface0 })
hi("StlMid",    { fg = c.text, bg = c.base })
hi("StlInfo",   { fg = c.base, bg = c.teal })
hi("StlPos",    { fg = c.base, bg = c.mauve, bold = true })

vim.opt.statusline = table.concat({
    "%#StlMode# %{toupper(mode())} ",
    "%#StlFile# %f%m%r ",
    "%#StlMid#%=",
    "%#StlInfo# %{&filetype!=''?&filetype:'none'} | %{&fileencoding!=''?&fileencoding:&encoding} ",
    "%#StlPos# %l:%c  %p%% ",
})

-- -----------------------------------------------------------------------------
-- Keymaps
-- -----------------------------------------------------------------------------
local map = function(mode, lhs, rhs, desc)
    vim.keymap.set(mode, lhs, rhs, { silent = true, noremap = true, desc = desc })
end

-- Quick save / quit
map("n", "<leader>w", ":w<CR>",  "Save")
map("n", "<leader>q", ":q<CR>",  "Quit")
map("n", "<leader>x", ":x<CR>",  "Save & quit")
map("n", "<leader>h", ":nohlsearch<CR>", "Clear search highlight")

-- Window navigation
map("n", "<C-h>", "<C-w>h")
map("n", "<C-j>", "<C-w>j")
map("n", "<C-k>", "<C-w>k")
map("n", "<C-l>", "<C-w>l")

-- Buffer navigation
map("n", "<S-l>", ":bnext<CR>",     "Next buffer")
map("n", "<S-h>", ":bprevious<CR>", "Prev buffer")
map("n", "<leader>bd", ":bdelete<CR>", "Close buffer")

-- Move lines
map("n", "<A-j>", ":m .+1<CR>==")
map("n", "<A-k>", ":m .-2<CR>==")
map("v", "<A-j>", ":m '>+1<CR>gv=gv")
map("v", "<A-k>", ":m '<-2<CR>gv=gv")

-- Indent in visual mode keeps selection
map("v", "<", "<gv")
map("v", ">", ">gv")

-- Center cursor on jumps
map("n", "<C-d>", "<C-d>zz")
map("n", "<C-u>", "<C-u>zz")
map("n", "n",     "nzzzv")
map("n", "N",     "Nzzzv")

-- File explorer (built-in netrw)
map("n", "<leader>e", ":Lexplore<CR>", "Toggle file tree")
vim.g.netrw_banner    = 0
vim.g.netrw_liststyle = 3
vim.g.netrw_winsize   = 22

-- -----------------------------------------------------------------------------
-- Autocommands
-- -----------------------------------------------------------------------------
local aug = vim.api.nvim_create_augroup("NovaShell", { clear = true })

-- Highlight yanked text
vim.api.nvim_create_autocmd("TextYankPost", {
    group = aug,
    callback = function() vim.highlight.on_yank({ timeout = 200 }) end,
})

-- Trim trailing whitespace on save
vim.api.nvim_create_autocmd("BufWritePre", {
    group = aug,
    pattern = "*",
    callback = function()
        local save = vim.fn.winsaveview()
        vim.cmd([[%s/\s\+$//e]])
        vim.fn.winrestview(save)
    end,
})

-- Restore last cursor position
vim.api.nvim_create_autocmd("BufReadPost", {
    group = aug,
    callback = function()
        local mark = vim.api.nvim_buf_get_mark(0, '"')
        local lcount = vim.api.nvim_buf_line_count(0)
        if mark[1] > 0 and mark[1] <= lcount then
            pcall(vim.api.nvim_win_set_cursor, 0, mark)
        end
    end,
})
